-- This migration adds new fields to the 'customers' table.

-- Add security_deposit column
ALTER TABLE customers
ADD COLUMN security_deposit NUMERIC;

-- Add deposit_date column
ALTER TABLE customers
ADD COLUMN deposit_date TIMESTAMP WITH TIME ZONE;

-- Add initial_cool_balance column
ALTER TABLE customers
ADD COLUMN initial_cool_balance NUMERIC;

-- Add initial_pet_balance column
ALTER TABLE customers
ADD COLUMN initial_pet_balance NUMERIC;

-- Add category column
ALTER TABLE customers
ADD COLUMN category TEXT;

-- Add is_active column
ALTER TABLE customers
ADD COLUMN is_active BOOLEAN;

-- Add discount_rate column
ALTER TABLE customers
ADD COLUMN discount_rate NUMERIC;

-- Add notes column
ALTER TABLE customers
ADD COLUMN notes TEXT;