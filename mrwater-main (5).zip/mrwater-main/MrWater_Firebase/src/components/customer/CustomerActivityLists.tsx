
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Delivery, Collection, Payment, Product } from "@/types";

interface CustomerActivityListsProps {
  deliveries: Delivery[];
  collections: Collection[];
  payments: Payment[];
  products: Product[];
}

export const CustomerActivityLists = ({
  deliveries,
  collections,
  payments,
  products
}: CustomerActivityListsProps) => {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium mb-2">Recent Deliveries</h3>
        {deliveries.length === 0 ? (
          <p className="text-muted-foreground text-sm">No deliveries recorded</p>
        ) : (
          <div className="rounded-md border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Products Delivered</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {deliveries.slice(0, 3).map(delivery => (
                  <TableRow key={delivery.id}>
                    <TableCell>{delivery.date}</TableCell>
                    <TableCell>
                      {Object.entries(delivery.jarsDelivered).map(([productId, count]) => {
                        const product = products.find(p => p.id === productId);
                        return product ? `${count} ${product.name}, ` : '';
                      })}
                    </TableCell>
                    <TableCell>{delivery.status}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>

      <div>
        <h3 className="text-lg font-medium mb-2">Recent Collections</h3>
        {collections.length === 0 ? (
          <p className="text-muted-foreground text-sm">No collections recorded</p>
        ) : (
          <div className="rounded-md border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Products Returned</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {collections.slice(0, 3).map(collection => (
                  <TableRow key={collection.id}>
                    <TableCell>{collection.date}</TableCell>
                    <TableCell>
                      {Object.entries(collection.jarsReturned).map(([productId, count]) => {
                        const product = products.find(p => p.id === productId);
                        return product ? `${count} ${product.name}, ` : '';
                      })}
                    </TableCell>
                    <TableCell>${collection.amount.toFixed(2)}</TableCell>
                    <TableCell>{collection.status}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>

      <div>
        <h3 className="text-lg font-medium mb-2">Recent Payments</h3>
        {payments.length === 0 ? (
          <p className="text-muted-foreground text-sm">No payments recorded</p>
        ) : (
          <div className="rounded-md border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Method</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {payments.slice(0, 3).map(payment => (
                  <TableRow key={payment.id}>
                    <TableCell>{payment.date}</TableCell>
                    <TableCell>${payment.amount.toFixed(2)}</TableCell>
                    <TableCell>{payment.paymentMethod.replace('_', ' ')}</TableCell>
                    <TableCell>{payment.status}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>
    </div>
  );
};
