
import { useState, useContext } from "react";
import { AppContext } from "@/context/AppContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { DialogHeader, DialogFooter, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { format } from "date-fns";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Customer } from "@/types";

interface CustomerDetailsDialogProps {
  customer: Customer;
  onClose: () => void;
}

const CustomerDetailsDialog = ({ customer, onClose }: CustomerDetailsDialogProps) => {
  const { updateCustomer, groups } = useContext(AppContext);
  const [name, setName] = useState(customer.name);
  const [address, setAddress] = useState(customer.address || "");
  const [contactNumber, setContactNumber] = useState(customer.contactNumber || "");
  const [depositAmount, setDepositAmount] = useState(customer.paymentBalance?.toString() || "0");
  const [depositDate, setDepositDate] = useState(customer.depositDate || format(new Date(), 'yyyy-MM-dd'));
  const [groupId, setGroupId] = useState(customer.groupId || "none");
  const [discountRate, setDiscountRate] = useState(customer.discountRate?.toString() || "0");
  const [notes, setNotes] = useState(customer.notes || "");
  const [petJars, setPetJars] = useState(customer.jarsHeld.pet?.toString() || "0");
  const [coolJars, setCoolJars] = useState(customer.jarsHeld.cool?.toString() || "0");
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    updateCustomer(customer.id, {
      name,
      address,
      contactNumber,
      paymentBalance: parseFloat(depositAmount),
      depositDate,
      groupId: groupId !== "none" ? groupId : undefined,
      discountRate: parseFloat(discountRate),
      notes,
      jarsHeld: {
        pet: parseInt(petJars),
        cool: parseInt(coolJars)
      }
    });
    
    toast({
      title: "Customer updated",
      description: `${name}'s details have been updated`,
    });
    
    onClose();
  };
  
  return (
    <>
      <DialogHeader>
        <DialogTitle>Customer Details</DialogTitle>
        <DialogDescription>
          View and edit customer information
        </DialogDescription>
      </DialogHeader>
      
      <form onSubmit={handleSubmit} className="space-y-4 py-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="name">Name</Label>
            <Input 
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="phone">Phone</Label>
            <Input 
              id="phone"
              value={contactNumber}
              onChange={(e) => setContactNumber(e.target.value)}
            />
          </div>
          
          <div className="space-y-2 col-span-2">
            <Label htmlFor="address">Address</Label>
            <Input 
              id="address"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="depositAmount">Deposit Amount</Label>
            <Input 
              id="depositAmount"
              type="number"
              step="0.01"
              value={depositAmount}
              onChange={(e) => setDepositAmount(e.target.value)}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="depositDate">Deposit Date</Label>
            <Input 
              id="depositDate"
              type="date"
              value={depositDate}
              onChange={(e) => setDepositDate(e.target.value)}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="petJars">Initial Pet Jars</Label>
            <Input 
              id="petJars"
              type="number"
              value={petJars}
              onChange={(e) => setPetJars(e.target.value)}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="coolJars">Initial Cool Jars</Label>
            <Input 
              id="coolJars"
              type="number"
              value={coolJars}
              onChange={(e) => setCoolJars(e.target.value)}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="group">Group</Label>
            <Select value={groupId} onValueChange={setGroupId}>
              <SelectTrigger id="group">
                <SelectValue placeholder="Select a group" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Not assigned</SelectItem>
                {groups.map(group => (
                  <SelectItem key={group.id} value={group.id}>
                    {group.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="discountRate">Discount Rate (%)</Label>
            <Input 
              id="discountRate"
              type="number"
              min="0"
              max="100"
              value={discountRate}
              onChange={(e) => setDiscountRate(e.target.value)}
            />
          </div>
          
          <div className="col-span-2 space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea 
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Add any additional notes here..."
              className="min-h-[100px]"
            />
          </div>
          
          <div className="col-span-2">
            <Label>Status</Label>
            <div className="mt-1">
              <Badge variant={customer.paymentBalance && customer.paymentBalance < 0 ? "destructive" : "secondary"}>
                {customer.paymentBalance && customer.paymentBalance < 0 ? "Pending" : "Active"}
              </Badge>
            </div>
          </div>
        </div>
        
        <DialogFooter>
          <Button type="submit">Save Changes</Button>
        </DialogFooter>
      </form>
    </>
  );
};

export default CustomerDetailsDialog;
