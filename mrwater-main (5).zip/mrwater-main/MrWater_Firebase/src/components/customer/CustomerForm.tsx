import { useState } from 'react';
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { DatePicker } from "@/components/ui/date-picker";
import { 
  User, 
  Phone, 
  MapPin, 
  DollarSign, 
  Calendar, 
  CircleDollarSign, 
  PawPrint,
  Folder,
  FileText,
  Percent 
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface CustomerFormProps {
  onSubmit: (data: {
    name: string;
    phone: string;
    address: string;
    securityDeposit: number;
    depositDate: Date;
    initialCoolBalance: number;
    initialPetBalance: number;
    category: string;
    isActive: boolean;
    discountRate: number;
    notes: string;
  }) => void;
  loading?: boolean;
  logChanges?: (changes: any) => Promise<void>;
  initialData?: any;
}

const CustomerForm = ({ onSubmit, loading, logChanges, initialData }: CustomerFormProps) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [securityDeposit, setSecurityDeposit] = useState(0);
  const [depositDate, setDepositDate] = useState<Date>(new Date());
  const [initialCoolBalance, setInitialCoolBalance] = useState(0);
  const [initialPetBalance, setInitialPetBalance] = useState(0);
  const [category, setCategory] = useState('residential');
  const [isActive, setIsActive] = useState(true);
  const [discountRate, setDiscountRate] = useState(0);
  const [notes, setNotes] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (initialData && logChanges) {
      const changes = {
        name: name !== initialData.name ? { from: initialData.name, to: name } : undefined,
        phone: phone !== initialData.phone ? { from: initialData.phone, to: phone } : undefined,
        address: address !== initialData.address ? { from: initialData.address, to: address } : undefined,
        securityDeposit: securityDeposit !== initialData.securityDeposit ? { from: initialData.securityDeposit, to: securityDeposit } : undefined,
        depositDate: depositDate !== initialData.depositDate ? { from: initialData.depositDate, to: depositDate } : undefined,
        initialCoolBalance: initialCoolBalance !== initialData.initialCoolBalance ? { from: initialData.initialCoolBalance, to: initialCoolBalance } : undefined,
        initialPetBalance: initialPetBalance !== initialData.initialPetBalance ? { from: initialData.initialPetBalance, to: initialPetBalance } : undefined,
        category: category !== initialData.category ? { from: initialData.category, to: category } : undefined,
        isActive: isActive !== initialData.isActive ? { from: initialData.isActive, to: isActive } : undefined,
        discountRate: discountRate !== initialData.discountRate ? { from: initialData.discountRate, to: discountRate } : undefined,
        notes: notes !== initialData.notes ? { from: initialData.notes, to: notes } : undefined,
      };

      const actualChanges = Object.fromEntries(
        Object.entries(changes).filter(([_, value]) => value !== undefined)
      );

      if (Object.keys(actualChanges).length > 0) {
        await logChanges(actualChanges);
      }
    }

    onSubmit({
      name,
      phone,
      address,
      securityDeposit,
      depositDate,
      initialCoolBalance,
      initialPetBalance,
      category,
      isActive,
      discountRate,
      notes
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="name">Name</Label>
        <div className="relative">
          <User className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            id="name"
            placeholder="Customer name"
            className="pl-8"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="phone">Phone</Label>
        <div className="relative">
          <Phone className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            id="phone"
            placeholder="Contact number"
            className="pl-8"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="address">Address</Label>
        <div className="relative">
          <MapPin className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            id="address"
            placeholder="Delivery address"
            className="pl-8"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="securityDeposit">Security Deposit</Label>
        <div className="relative">
          <DollarSign className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            id="securityDeposit"
            type="number"
            className="pl-8"
            value={securityDeposit}
            onChange={(e) => setSecurityDeposit(Number(e.target.value))}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="depositDate">Deposit Date</Label>
        <div className="relative">
          <DatePicker date={depositDate} setDate={setDepositDate} />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="initialCoolBalance">Initial Cool Balance</Label>
        <div className="relative">
          <CircleDollarSign className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            id="initialCoolBalance"
            type="number"
            className="pl-8"
            value={initialCoolBalance}
            onChange={(e) => setInitialCoolBalance(Number(e.target.value))}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="initialPetBalance">Initial Pet Balance</Label>
        <div className="relative">
          <PawPrint className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            id="initialPetBalance"
            type="number"
            className="pl-8"
            value={initialPetBalance}
            onChange={(e) => setInitialPetBalance(Number(e.target.value))}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="category">Category</Label>
        <div className="relative">
          <Select value={category} onValueChange={setCategory}>
            <SelectTrigger>
              <Folder className="mr-2 h-4 w-4" />
              <SelectValue placeholder="Select category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="residential">Residential</SelectItem>
              <SelectItem value="commercial">Commercial</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="isActive">Active Status</Label>
        <div className="flex items-center space-x-2">
          <Switch
            id="isActive"
            checked={isActive}
            onCheckedChange={setIsActive}
          />
          <Label htmlFor="isActive">{isActive ? 'Active' : 'Inactive'}</Label>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="discountRate">Discount Rate (%)</Label>
        <div className="relative">
          <Percent className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            id="discountRate"
            type="number"
            min="0"
            max="100"
            className="pl-8"
            value={discountRate}
            onChange={(e) => setDiscountRate(Number(e.target.value))}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="notes">Notes</Label>
        <div className="relative">
          <FileText className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Textarea
            id="notes"
            placeholder="Additional notes..."
            className="min-h-[100px] pl-8"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
          />
        </div>
      </div>

      <Button type="submit" disabled={loading}>
        Add Customer
      </Button>
    </form>
  );
};

export default CustomerForm;
