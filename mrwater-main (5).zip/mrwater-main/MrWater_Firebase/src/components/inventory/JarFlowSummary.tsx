
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

interface JarFlowSummaryProps {
  totalInventory: {
    cool: number;
    pet: number;
  };
  totalJarsWithCustomers: {
    cool: number;
    pet: number;
  };
}

const JarFlowSummary = ({ totalInventory, totalJarsWithCustomers }: JarFlowSummaryProps) => {
  const totalJarsInInventory = totalInventory.cool + totalInventory.pet;
  const totalJarsOut = totalJarsWithCustomers.cool + totalJarsWithCustomers.pet;
  const totalJarsInCirculation = totalJarsInInventory + totalJarsOut;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Jar Flow Summary</CardTitle>
        <CardDescription>Overview of all jars in circulation</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <p className="text-sm font-medium">Cool Jars</p>
            <p className="text-2xl font-bold">{totalInventory.cool + totalJarsWithCustomers.cool}</p>
            <p className="text-xs text-muted-foreground">
              {totalInventory.cool} in inventory, {totalJarsWithCustomers.cool} with customers
            </p>
          </div>
          <div className="space-y-2">
            <p className="text-sm font-medium">PET Jars</p>
            <p className="text-2xl font-bold">{totalInventory.pet + totalJarsWithCustomers.pet}</p>
            <p className="text-xs text-muted-foreground">
              {totalInventory.pet} in inventory, {totalJarsWithCustomers.pet} with customers
            </p>
          </div>
        </div>
        <div className="mt-6">
          <p className="text-sm font-medium">Total Jars in Circulation</p>
          <p className="text-2xl font-bold">{totalJarsInCirculation}</p>
          <p className="text-xs text-muted-foreground">
            {totalJarsInInventory} in inventory, {totalJarsOut} with customers
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default JarFlowSummary;
