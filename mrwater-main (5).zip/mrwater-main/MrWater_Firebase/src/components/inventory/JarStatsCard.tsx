
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";

interface JarStatsCardProps {
  title: string;
  totalCount: number;
  availableCount: number;
  color: string;
}

const JarStatsCard = ({ title, totalCount, availableCount, color }: JarStatsCardProps) => {
  const percentAvailable = totalCount > 0 
    ? Math.round((availableCount / totalCount) * 100) 
    : 0;

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{availableCount} / {totalCount}</div>
        <p className="text-xs text-muted-foreground">Available jars</p>
        <div className="mt-4 h-4">
          <Progress 
            value={percentAvailable} 
            className="bg-secondary h-2" 
          />
        </div>
        <p className="mt-2 text-xs text-right font-medium" style={{ color }}>
          {percentAvailable}% Available
        </p>
      </CardContent>
    </Card>
  );
};

export default JarStatsCard;
