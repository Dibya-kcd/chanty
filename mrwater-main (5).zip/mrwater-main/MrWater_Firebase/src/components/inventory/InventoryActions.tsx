
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { AppContext } from "@/context/AppContext";
import { useContext, useState } from "react";
import { toast } from "@/hooks/use-toast";

const InventoryActions = () => {
  const { updateJarInventory } = useContext(AppContext);
  const [newCoolJars, setNewCoolJars] = useState<number>(0);
  const [newPetJars, setNewPetJars] = useState<number>(0);

  const handleAddJars = () => {
    if (newCoolJars === 0 && newPetJars === 0) {
      toast({
        title: "No jars to add",
        description: "Please specify the number of jars to add",
        variant: "destructive",
      });
      return;
    }

    updateJarInventory({ 
      cool: newCoolJars,
      pet: newPetJars
    });
    
    toast({
      title: "Inventory updated",
      description: `Added ${newCoolJars} Cool jars and ${newPetJars} PET jars to inventory`,
    });
    
    setNewCoolJars(0);
    setNewPetJars(0);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Manage Inventory</CardTitle>
        <CardDescription>Add new jars to your inventory</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="cool-jars">Cool Jars</Label>
            <Input
              id="cool-jars"
              type="number"
              min="0"
              value={newCoolJars}
              onChange={(e) => setNewCoolJars(parseInt(e.target.value) || 0)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="pet-jars">PET Jars</Label>
            <Input
              id="pet-jars"
              type="number"
              min="0"
              value={newPetJars}
              onChange={(e) => setNewPetJars(parseInt(e.target.value) || 0)}
            />
          </div>
        </div>
        <Button onClick={handleAddJars} className="w-full">
          Add Jars to Inventory
        </Button>
      </CardContent>
    </Card>
  );
};

export default InventoryActions;
