
// Use the auto-generated Supabase client instead of creating a new one
import { supabase } from "@/integrations/supabase/client";
import type { Database } from '@/types/supabase';

export { supabase };
