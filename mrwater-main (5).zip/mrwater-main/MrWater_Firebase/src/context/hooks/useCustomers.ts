
import { useState, useEffect } from "react";
import { Customer } from "@/types";
import { supabase } from "@/lib/supabase";
import { useToast } from "@/hooks/use-toast";

export function useCustomers() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  // Fetch customers from Supabase
  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        setLoading(true);
        const { data, error } = await supabase
          .from('customers')
          .select('*');

        if (error) {
          throw error;
        }

        if (data) {
          // Ensure we properly convert the jarsHeld JSON to the expected type
          const formattedCustomers: Customer[] = data.map((customer) => ({
            id: customer.id,
            name: customer.name,
            // Explicitly cast the jarsHeld to the expected type
            jarsHeld: customer.jars_held as { [productId: string]: number },
            address: customer.address || undefined,
            contactNumber: customer.contact_number || undefined,
            groupId: customer.group_id || undefined,
            paymentBalance: customer.payment_balance || undefined,
          }));

          setCustomers(formattedCustomers);
        }
      } catch (error: any) {
        console.error('Error fetching customers:', error.message);
        toast({
          title: "Error fetching customers",
          description: error.message,
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    fetchCustomers();

    // Subscribe to changes in the customers table
    const subscription = supabase
      .channel('public:customers')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'customers' }, async () => {
        await fetchCustomers();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(subscription);
    };
  }, [toast]);

  // Customer management functions
  const addCustomer = async (customer: Omit<Customer, "id">) => {
    try {
      const { data, error } = await supabase
        .from('customers')
        .insert([{
          name: customer.name,
          jars_held: customer.jarsHeld,
          address: customer.address || null,
          contact_number: customer.contactNumber || null,
          group_id: customer.groupId || null,
          payment_balance: customer.paymentBalance || null,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }])
        .select()
        .single();

      if (error) throw error;

      if (data) {
        const newCustomer: Customer = {
          id: data.id,
          name: data.name,
          // Explicitly cast the jarsHeld to the expected type
          jarsHeld: data.jars_held as { [productId: string]: number },
          address: data.address || undefined,
          contactNumber: data.contact_number || undefined,
          groupId: data.group_id || undefined,
          paymentBalance: data.payment_balance || undefined,
        };

        setCustomers((prev) => [...prev, newCustomer]);
      }
    } catch (error: any) {
      console.error('Error adding customer:', error.message);
      toast({
        title: "Error adding customer",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const updateCustomer = async (id: string, customer: Partial<Customer>) => {
    try {
      // Convert from client model to database model
      const dbCustomer: any = {};
      if (customer.name !== undefined) dbCustomer.name = customer.name;
      if (customer.jarsHeld !== undefined) dbCustomer.jars_held = customer.jarsHeld;
      if (customer.address !== undefined) dbCustomer.address = customer.address;
      if (customer.contactNumber !== undefined) dbCustomer.contact_number = customer.contactNumber;
      if (customer.groupId !== undefined) dbCustomer.group_id = customer.groupId;
      if (customer.paymentBalance !== undefined) dbCustomer.payment_balance = customer.paymentBalance;
      dbCustomer.updated_at = new Date().toISOString();

      const { error } = await supabase
        .from('customers')
        .update(dbCustomer)
        .eq('id', id);

      if (error) throw error;

      // Update the local state immediately to reflect changes
      setCustomers((prev) =>
        prev.map((c) => (c.id === id ? { ...c, ...customer } : c))
      );
    } catch (error: any) {
      console.error('Error updating customer:', error.message);
      toast({
        title: "Error updating customer",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const removeCustomer = async (id: string) => {
    try {
      const { error } = await supabase
        .from('customers')
        .delete()
        .eq('id', id);

      if (error) throw error;

      setCustomers((prev) => prev.filter((c) => c.id !== id));
    } catch (error: any) {
      console.error('Error removing customer:', error.message);
      toast({
        title: "Error removing customer",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  // Customer group assignment functions
  const assignCustomerToGroup = async (customerId: string, groupId: string) => {
    await updateCustomer(customerId, { groupId });
  };

  const removeCustomerFromGroup = async (customerId: string) => {
    await updateCustomer(customerId, { groupId: undefined });
  };

  return {
    customers,
    setCustomers,
    addCustomer,
    updateCustomer,
    removeCustomer,
    assignCustomerToGroup,
    removeCustomerFromGroup,
    loading,
  };
}
