
import { useState } from "react";
import { Group } from "@/types";
import { initialGroups } from "../initialData";
import { generateId } from "../utils";

export function useGroups(setCustomers: React.Dispatch<React.SetStateAction<any[]>>) {
  const [groups, setGroups] = useState<Group[]>(initialGroups);

  // Group management functions
  const addGroup = (group: Omit<Group, "id">) => {
    const newGroup = {
      ...group,
      id: generateId(),
    };
    setGroups((prev) => [...prev, newGroup]);
  };

  const updateGroup = (id: string, group: Partial<Group>) => {
    setGroups((prev) =>
      prev.map((g) => (g.id === id ? { ...g, ...group } : g))
    );
  };

  const removeGroup = (id: string) => {
    setGroups((prev) => prev.filter((g) => g.id !== id));
    setCustomers((prev) =>
      prev.map((c) => (c.groupId === id ? { ...c, groupId: undefined } : c))
    );
  };

  return {
    groups,
    addGroup,
    updateGroup,
    removeGroup,
  };
}
