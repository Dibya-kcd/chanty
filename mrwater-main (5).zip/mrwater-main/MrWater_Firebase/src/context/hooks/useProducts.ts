
import { useState } from "react";
import { Product } from "@/types";
import { initialProducts } from "../initialData";
import { generateId } from "../utils";

export function useProducts() {
  const [products, setProducts] = useState<Product[]>(initialProducts);

  // Product management functions
  const addProduct = (product: Omit<Product, "id">) => {
    const newProduct = {
      ...product,
      id: generateId(),
    };
    setProducts((prev) => [...prev, newProduct]);
  };

  const updateProduct = (id: string, product: Partial<Product>) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...product } : p))
    );
  };

  const removeProduct = (id: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== id));
  };

  return {
    products,
    addProduct,
    updateProduct,
    removeProduct,
  };
}
