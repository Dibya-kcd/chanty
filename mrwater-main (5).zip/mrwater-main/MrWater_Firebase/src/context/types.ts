
import { Customer, Inventory, Group, Delivery, Collection, Payment, Product } from "@/types";

export interface AppContextType {
  inventory: Inventory;
  customers: Customer[];
  groups: Group[];
  deliveries: Delivery[];
  collections: Collection[];
  payments: Payment[];
  products: Product[];
  updateJarInventory: (jars: { cool: number; pet: number }) => void;
  addCustomer: (customer: Omit<Customer, "id">) => void;
  updateCustomer: (id: string, customer: Partial<Customer>) => void;
  removeCustomer: (id: string) => void;
  addGroup: (group: Omit<Group, "id">) => void;
  updateGroup: (id: string, group: Partial<Group>) => void;
  removeGroup: (id: string) => void;
  assignCustomerToGroup: (customerId: string, groupId: string) => void;
  removeCustomerFromGroup: (customerId: string) => void;
  addDelivery: (delivery: Omit<Delivery, "id">) => void;
  updateDelivery: (id: string, delivery: Partial<Delivery>) => void;
  removeDelivery: (id: string) => void;
  addCollection: (collection: Omit<Collection, "id">) => void;
  updateCollection: (id: string, collection: Partial<Collection>) => void;
  removeCollection: (id: string) => void;
  addPayment: (payment: Omit<Payment, "id">) => void;
  updatePayment: (id: string, payment: Partial<Payment>) => void;
  removePayment: (id: string) => void;
  addProduct: (product: Omit<Product, "id">) => void;
  updateProduct: (id: string, product: Partial<Product>) => void;
  removeProduct: (id: string) => void;
}
