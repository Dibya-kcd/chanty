
import { useState, useEffect, useContext } from "react";
import { AppContext } from "@/context/AppContext";
import { format } from "date-fns";
import { Customer } from "@/types";
import { supabase } from "@/integrations/supabase/client";

export const useCustomerData = (customerId: string) => {
  const { 
    customers, 
    deliveries, 
    collections, 
    payments,
    updateCustomer, 
    removeCustomer
  } = useContext(AppContext);
  
  const [name, setName] = useState("");
  const [address, setAddress] = useState("");
  const [contactNumber, setContactNumber] = useState("");
  const [groupId, setGroupId] = useState<string | undefined>(undefined);
  const [productJars, setProductJars] = useState<Record<string, number>>({});
  const [paymentBalance, setPaymentBalance] = useState<number>(0);
  
  const customer = customers.find(c => c.id === customerId);
  const customerDeliveries = deliveries.filter(d => d.customerId === customerId);
  const customerCollections = collections.filter(c => c.customerId === customerId);
  const customerPayments = payments.filter(p => p.customerId === customerId);
  
  useEffect(() => {
    if (customer) {
      setName(customer.name);
      setAddress(customer.address || "");
      setContactNumber(customer.contactNumber || "");
      setGroupId(customer.groupId);
      setProductJars(customer.jarsHeld || {});
      setPaymentBalance(customer.paymentBalance || 0);
    }
  }, [customer]);

  const logTransactionChange = async (
    entityType: 'delivery' | 'collection' | 'payment',
    entityId: string,
    action: 'created' | 'updated' | 'deleted',
    changes: any
  ) => {
    try {
      await supabase
        .from('transaction_history_logs')
        .insert({
          customer_id: customerId,
          entity_type: entityType,
          entity_id: entityId,
          action,
          changes,
        });
    } catch (error) {
      console.error('Error logging transaction:', error);
    }
  };

  return {
    customer,
    customerDeliveries,
    customerCollections,
    customerPayments,
    name,
    setName,
    address,
    setAddress,
    contactNumber,
    setContactNumber,
    groupId,
    setGroupId,
    productJars,
    setProductJars,
    paymentBalance,
    setPaymentBalance,
    updateCustomer,
    removeCustomer,
    logTransactionChange
  };
};
