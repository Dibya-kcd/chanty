export interface Customer {
  id: string;
  name: string;
  jarsHeld: {
    [productId: string]: number;
  };
  address?: string;
  contactNumber?: string;
  groupId?: string;
  paymentBalance?: number;
  depositDate?: string;
  discountRate?: number;
  notes?: string;
}

export interface Inventory {
  cool: number;
  pet: number;
}

export interface Group {
  id: string;
  name: string;
  description?: string;
  collectionDay?: string;
  amountDue?: number;
}

export interface Delivery {
  id: string;
  customerId: string;
  date: string;
  jarsDelivered: {
    [productId: string]: number;
  };
  status: 'pending' | 'completed' | 'cancelled';
}

export interface Collection {
  id: string;
  customerId: string;
  date: string;
  amount: number;
  jarsReturned: {
    [productId: string]: number;
  };
  status: 'pending' | 'completed' | 'cancelled';
}

export interface Payment {
  id: string;
  customerId: string;
  date: string;
  amount: number;
  paymentMethod: 'cash' | 'card' | 'bank_transfer';
  status: 'pending' | 'completed' | 'failed';
}

export interface Product {
  id: string;
  name: string;
  type: string;
  price: number;
  description?: string;
  inStock: number;
}

export interface CustomerDailyEntry {
  date: string;
  delivery?: {
    [productId: string]: number;
  };
  collection?: {
    [productId: string]: number;
    amount: number;
  };
  payment?: {
    amount: number;
    paymentMethod: 'cash' | 'card' | 'bank_transfer';
  };
}
