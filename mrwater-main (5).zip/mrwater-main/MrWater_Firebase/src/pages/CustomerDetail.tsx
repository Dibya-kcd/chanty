
import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useCustomerData } from "@/hooks/useCustomerData";
import { AppContext } from "@/context/AppContext";
import AppLayout from "@/components/layout/AppLayout";
import { Button } from "@/components/ui/button";
import { useContext } from "react";
import { format } from "date-fns";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { toast } from "@/hooks/use-toast";
import { ArrowLeft, Trash2, CalendarIcon } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import CustomerDailyEntryForm from "@/components/customer/CustomerDailyEntryForm";
import { TransactionHistoryList } from '@/components/customer/TransactionHistoryList';
import { CustomerDetailsSection } from "@/components/customer/CustomerDetailsSection";
import { CustomerActivityLists } from "@/components/customer/CustomerActivityLists";

const CustomerDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { groups, products, assignCustomerToGroup, removeCustomerFromGroup } = useContext(AppContext);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  
  const {
    customer,
    customerDeliveries,
    customerCollections,
    customerPayments,
    name,
    setName,
    address,
    setAddress,
    contactNumber,
    setContactNumber,
    groupId,
    setGroupId,
    productJars,
    setProductJars,
    paymentBalance,
    setPaymentBalance,
    updateCustomer,
    removeCustomer,
    logTransactionChange
  } = useCustomerData(id || '');
  
  // Find entries for the selected date
  const deliveryForSelectedDate = customerDeliveries.find(d => 
    d.date === format(selectedDate, 'yyyy-MM-dd')
  );
  
  const collectionForSelectedDate = customerCollections.find(c => 
    c.date === format(selectedDate, 'yyyy-MM-dd')
  );
  
  const paymentForSelectedDate = customerPayments.find(p => 
    p.date === format(selectedDate, 'yyyy-MM-dd')
  );

  const handleDelete = async () => {
    if (!customer) return;
    
    await logTransactionChange('delivery', customer.id, 'deleted', {
      name: customer.name,
      jarsHeld: customer.jarsHeld,
      paymentBalance: customer.paymentBalance
    });
    
    removeCustomer(customer.id);
    
    toast({
      title: "Customer deleted",
      description: `${customer.name} has been removed`,
    });
    
    navigate("/customers");
  };

  const handleSave = async () => {
    if (!customer) return;
    
    const changes = {
      name: name !== customer.name ? { from: customer.name, to: name } : undefined,
      address: address !== customer.address ? { from: customer.address, to: address } : undefined,
      contactNumber: contactNumber !== customer.contactNumber ? { from: customer.contactNumber, to: contactNumber } : undefined,
      groupId: groupId !== customer.groupId ? { from: customer.groupId, to: groupId } : undefined,
      paymentBalance: paymentBalance !== customer.paymentBalance ? { from: customer.paymentBalance, to: paymentBalance } : undefined,
      jarsHeld: JSON.stringify(productJars) !== JSON.stringify(customer.jarsHeld) ? { from: customer.jarsHeld, to: productJars } : undefined,
    };

    const actualChanges = Object.fromEntries(
      Object.entries(changes).filter(([_, value]) => value !== undefined)
    );

    if (Object.keys(actualChanges).length > 0) {
      await logTransactionChange('delivery', customer.id, 'updated', actualChanges);
    }
    
    updateCustomer(customer.id, {
      name,
      address,
      contactNumber,
      jarsHeld: productJars,
      paymentBalance
    });
    
    if (groupId && groupId !== customer.groupId) {
      assignCustomerToGroup(customer.id, groupId);
    } else if (!groupId && customer.groupId) {
      removeCustomerFromGroup(customer.id);
    }
    
    toast({
      title: "Customer updated",
      description: "Customer details have been saved",
    });
  };

  if (!customer) return null;
  
  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <Button variant="outline" size="sm" onClick={() => navigate("/customers")}>
            <ArrowLeft size={16} className="mr-2" />
            Back to Customers
          </Button>
          
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" size="sm">
                <Trash2 size={16} className="mr-2" />
                Delete Customer
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will permanently delete {customer.name} and all associated data.
                  This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>

        <Tabs defaultValue="entries">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="entries">Daily Entries</TabsTrigger>
            <TabsTrigger value="details">Customer Details</TabsTrigger>
            <TabsTrigger value="history">Transaction History</TabsTrigger>
          </TabsList>
          
          <TabsContent value="entries" className="mt-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Daily Entries</CardTitle>
                    <CardDescription>
                      Manage deliveries, collections, and payments for {customer.name}
                    </CardDescription>
                  </div>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-[240px] justify-start text-left font-normal"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {format(selectedDate, "PPP")}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="end">
                      <Calendar
                        mode="single"
                        selected={selectedDate}
                        onSelect={(date) => date && setSelectedDate(date)}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </CardHeader>
              <CardContent>
                <CustomerDailyEntryForm 
                  customerId={customer.id}
                  customerName={customer.name}
                  date={selectedDate}
                  initialDelivery={deliveryForSelectedDate}
                  initialCollection={collectionForSelectedDate}
                  initialPayment={paymentForSelectedDate}
                  products={products}
                />
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="details" className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="md:col-span-1">
                <CardHeader>
                  <CardTitle>Customer Details</CardTitle>
                  <CardDescription>Update customer information</CardDescription>
                </CardHeader>
                <CardContent>
                  <CustomerDetailsSection 
                    customer={customer}
                    name={name}
                    setName={setName}
                    address={address}
                    setAddress={setAddress}
                    contactNumber={contactNumber}
                    setContactNumber={setContactNumber}
                    groupId={groupId}
                    setGroupId={setGroupId}
                    paymentBalance={paymentBalance}
                    setPaymentBalance={setPaymentBalance}
                    productJars={productJars}
                    setProductJars={setProductJars}
                    groups={groups}
                    products={products}
                    onSave={handleSave}
                  />
                </CardContent>
              </Card>
              
              <Card className="md:col-span-2">
                <CardHeader>
                  <CardTitle>Customer Activity</CardTitle>
                  <CardDescription>Recent deliveries, collections, and payments</CardDescription>
                </CardHeader>
                <CardContent>
                  <CustomerActivityLists 
                    deliveries={customerDeliveries}
                    collections={customerCollections}
                    payments={customerPayments}
                    products={products}
                  />
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="history" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Transaction History</CardTitle>
                <CardDescription>
                  View all changes and activities for {customer?.name}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <TransactionHistoryList customerId={id || ''} />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
};

export default CustomerDetail;
