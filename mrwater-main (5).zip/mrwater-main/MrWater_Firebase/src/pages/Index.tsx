import { Link } from "react-router-dom";
import { Package, Users, Truck, ArrowDown, CreditCard, BarChart, UserPlus } from "lucide-react";

const Feature = ({ icon, title, description, link }: { 
  icon: React.ReactNode; 
  title: string; 
  description: string;
  link: string;
}) => (
  <Link to={link} className="block p-6 bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow">
    <div className="flex items-center gap-4 mb-3">
      <div className="p-2 bg-primary/10 rounded-full text-primary">
        {icon}
      </div>
      <h3 className="text-xl font-bold">{title}</h3>
    </div>
    <p className="text-gray-600">{description}</p>
  </Link>
);

const Index = () => {
  return (
    <div className="min-h-screen bg-gray-100">
      <div className="container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Mr Water - Water Jar Management System</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Complete solution for tracking inventory, managing customers, 
            scheduling deliveries, and handling payments for your water jar service
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <Feature
            icon={<BarChart size={24} />}
            title="Dashboard"
            description="Get a complete overview of your water jar business at a glance"
            link="/dashboard"
          />
          <Feature
            icon={<Package size={24} />}
            title="Inventory Management"
            description="Track your Cool and PET jar inventory and manage stock levels"
            link="/inventory"
          />
          <Feature
            icon={<Users size={24} />}
            title="Customer Management"
            description="Maintain customer information and track jar holdings"
            link="/customers"
          />
          <Feature
            icon={<UserPlus size={24} />}
            title="Group Management"
            description="Organize customers into groups for efficient delivery routes"
            link="/groups"
          />
          <Feature
            icon={<Truck size={24} />}
            title="Delivery Tracking"
            description="Schedule and track jar deliveries to customers"
            link="/deliveries"
          />
          <Feature
            icon={<ArrowDown size={24} />}
            title="Collection Management"
            description="Record jar returns and payments collected from customers"
            link="/collections"
          />
          <Feature
            icon={<CreditCard size={24} />}
            title="Payment Processing"
            description="Process and track customer payments and manage accounts"
            link="/payments"
          />
        </div>
        
        <div className="text-center">
          <Link 
            to="/dashboard" 
            className="bg-primary hover:bg-primary/90 text-white px-6 py-3 rounded-md transition-colors inline-flex items-center gap-2"
          >
            <BarChart size={20} />
            Go to Dashboard
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Index;
