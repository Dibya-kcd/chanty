
import { useContext, useState } from "react";
import { AppContext } from "@/context/AppContext";
import AppLayout from "@/components/layout/AppLayout";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { UserPlus, Users, Edit, Trash2, Calendar } from "lucide-react";
import { Link } from "react-router-dom";
import { toast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Group } from "@/types";

const GroupCard = ({ group }: { group: Group }) => {
  const { customers, removeGroup } = useContext(AppContext);
  
  // Count customers in this group
  const customerCount = customers.filter(c => c.groupId === group.id).length;
  
  const handleDelete = () => {
    removeGroup(group.id);
    toast({
      title: "Group deleted",
      description: `${group.name} has been removed`,
    });
  };
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>{group.name}</CardTitle>
        <CardDescription>{group.description}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Users size={16} />
            <span className="text-sm">{customerCount} customers</span>
          </div>
          
          {group.collectionDay && (
            <div className="flex items-center gap-2">
              <Calendar size={16} />
              <span className="text-sm">Collection day: {group.collectionDay}</span>
            </div>
          )}
          
          {group.amountDue && group.amountDue > 0 && (
            <div className="flex items-center gap-2">
              <Badge variant="secondary">${group.amountDue.toFixed(2)} due</Badge>
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" size="sm" asChild>
          <Link to={`/groups/${group.id}`}>
            <Edit size={16} className="mr-2" />
            Manage
          </Link>
        </Button>
        <Button variant="destructive" size="sm" onClick={handleDelete}>
          <Trash2 size={16} className="mr-2" />
          Delete
        </Button>
      </CardFooter>
    </Card>
  );
};

const AddGroupDialog = () => {
  const { addGroup } = useContext(AppContext);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [collectionDay, setCollectionDay] = useState("");
  const [open, setOpen] = useState(false);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    addGroup({
      name,
      description,
      collectionDay,
      amountDue: 0,
    });
    
    toast({
      title: "Group created",
      description: `${name} has been added to your groups`,
    });
    
    // Reset form
    setName("");
    setDescription("");
    setCollectionDay("");
    setOpen(false);
  };
  
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <UserPlus size={16} className="mr-2" />
          Add New Group
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Create New Group</DialogTitle>
          <DialogDescription>
            Add a new customer group for organizing delivery routes
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit}>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Group Name</Label>
              <Input 
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Downtown Business District"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Input 
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="All businesses in the downtown area"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="collectionDay">Collection Day</Label>
              <Input 
                id="collectionDay"
                value={collectionDay}
                onChange={(e) => setCollectionDay(e.target.value)}
                placeholder="Monday"
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button type="submit">Add Group</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

const Groups = () => {
  const { groups } = useContext(AppContext);
  
  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Customer Groups</h2>
            <p className="text-muted-foreground">
              Organize customers into groups for easier management and routing
            </p>
          </div>
          <AddGroupDialog />
        </div>
        
        {groups.length === 0 ? (
          <div className="rounded-md bg-muted p-8 text-center">
            <UserPlus size={48} className="mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">No Groups Found</h3>
            <p className="text-muted-foreground mb-4">
              Create your first customer group to organize your customers
            </p>
            <AddGroupDialog />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {groups.map((group) => (
              <GroupCard key={group.id} group={group} />
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
};

export default Groups;
