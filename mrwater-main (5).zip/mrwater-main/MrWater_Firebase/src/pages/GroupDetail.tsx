
import { useContext, useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { AppContext } from "@/context/AppContext";
import AppLayout from "@/components/layout/AppLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { toast } from "@/hooks/use-toast";
import { ArrowLeft, Users, UserMinus, Save } from "lucide-react";

const GroupDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { groups, customers, updateGroup, removeCustomerFromGroup, assignCustomerToGroup } = useContext(AppContext);
  
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [collectionDay, setCollectionDay] = useState("");
  const [amountDue, setAmountDue] = useState(0);
  const [selectedCustomerId, setSelectedCustomerId] = useState("");
  
  // Find the group
  const group = groups.find(g => g.id === id);
  
  // Filter customers in this group
  const groupCustomers = customers.filter(c => c.groupId === id);
  
  // Get customers not in any group
  const availableCustomers = customers.filter(c => !c.groupId);
  
  useEffect(() => {
    if (group) {
      setName(group.name);
      setDescription(group.description || "");
      setCollectionDay(group.collectionDay || "");
      setAmountDue(group.amountDue || 0);
    } else {
      navigate("/groups");
    }
  }, [group, navigate]);
  
  const handleSave = () => {
    if (!group) return;
    
    updateGroup(group.id, {
      name,
      description,
      collectionDay,
      amountDue,
    });
    
    toast({
      title: "Group updated",
      description: "Group details have been saved",
    });
  };
  
  const handleRemoveCustomer = (customerId: string, customerName: string) => {
    removeCustomerFromGroup(customerId);
    
    toast({
      title: "Customer removed from group",
      description: `${customerName} has been removed from ${name}`,
    });
  };
  
  const handleAddCustomer = () => {
    if (!selectedCustomerId) return;
    
    const customer = customers.find(c => c.id === selectedCustomerId);
    if (!customer) return;
    
    assignCustomerToGroup(selectedCustomerId, id!);
    
    toast({
      title: "Customer added to group",
      description: `${customer.name} has been added to ${name}`,
    });
    
    setSelectedCustomerId("");
  };
  
  if (!group) return null;
  
  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => navigate("/groups")}>
            <ArrowLeft size={16} className="mr-2" />
            Back to Groups
          </Button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Group details */}
          <Card className="md:col-span-1">
            <CardHeader>
              <CardTitle>Group Details</CardTitle>
              <CardDescription>Update information about this group</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Group Name</Label>
                  <Input 
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Input 
                    id="description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="collectionDay">Collection Day</Label>
                  <Input 
                    id="collectionDay"
                    value={collectionDay}
                    onChange={(e) => setCollectionDay(e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="amountDue">Amount Due ($)</Label>
                  <Input 
                    id="amountDue"
                    type="number"
                    min="0"
                    step="0.01"
                    value={amountDue}
                    onChange={(e) => setAmountDue(parseFloat(e.target.value) || 0)}
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={handleSave} className="w-full">
                <Save size={16} className="mr-2" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>
          
          {/* Group customers */}
          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle>Customers in this Group</CardTitle>
              <CardDescription>
                {groupCustomers.length} customers assigned to {name}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {/* Add customer form */}
              {availableCustomers.length > 0 && (
                <div className="flex items-end gap-2 mb-6">
                  <div className="flex-1 space-y-2">
                    <Label htmlFor="customer">Add Customer</Label>
                    <Select value={selectedCustomerId} onValueChange={setSelectedCustomerId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a customer" />
                      </SelectTrigger>
                      <SelectContent>
                        {availableCustomers.map(customer => (
                          <SelectItem key={customer.id} value={customer.id}>
                            {customer.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <Button onClick={handleAddCustomer} disabled={!selectedCustomerId}>
                    Add to Group
                  </Button>
                </div>
              )}
              
              {groupCustomers.length === 0 ? (
                <div className="rounded-md bg-muted p-8 text-center">
                  <Users size={48} className="mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium mb-2">No Customers in this Group</h3>
                  <p className="text-muted-foreground">
                    Add customers to this group to organize delivery routes
                  </p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Customer</TableHead>
                      <TableHead>Contact</TableHead>
                      <TableHead>Jars Held</TableHead>
                      <TableHead></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {groupCustomers.map(customer => (
                      <TableRow key={customer.id}>
                        <TableCell className="font-medium">{customer.name}</TableCell>
                        <TableCell>{customer.contactNumber || "—"}</TableCell>
                        <TableCell>
                          {Object.values(customer.jarsHeld).reduce((sum, count) => sum + count, 0)} jars
                        </TableCell>
                        <TableCell className="text-right">
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleRemoveCustomer(customer.id, customer.name)}
                          >
                            <UserMinus size={16} className="mr-2" />
                            Remove
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
};

export default GroupDetail;
