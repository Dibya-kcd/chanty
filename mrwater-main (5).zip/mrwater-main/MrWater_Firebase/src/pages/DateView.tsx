
import { useContext, useState } from "react";
import { AppContext } from "@/context/AppContext";
import AppLayout from "@/components/layout/AppLayout";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { format } from "date-fns";
import { ArrowDown, Calendar as CalendarIcon, DollarSign, Package, Plus, Truck } from "lucide-react";
import { Collection, Delivery } from "@/types";

const DateView = () => {
  const { deliveries, collections, customers } = useContext(AppContext);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  
  // Filter deliveries and collections for the selected date
  const filteredDeliveries = selectedDate
    ? deliveries.filter((delivery) => 
        delivery.date === format(selectedDate, "yyyy-MM-dd")
      )
    : [];
    
  const filteredCollections = selectedDate
    ? collections.filter((collection) => 
        collection.date === format(selectedDate, "yyyy-MM-dd")
      )
    : [];
  
  // Get customer names
  const getCustomerName = (customerId: string) => {
    const customer = customers.find((c) => c.id === customerId);
    return customer ? customer.name : "Unknown";
  };
  
  return (
    <AppLayout>
      <div className="space-y-6">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Date View</h2>
          <p className="text-muted-foreground">
            View and manage deliveries and collections by date
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="md:col-span-1">
            <CardHeader>
              <CardTitle>Select Date</CardTitle>
              <CardDescription>
                Choose a date to view its deliveries and collections
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                className="rounded-md border p-3 pointer-events-auto"
              />
              
              <div className="mt-4 space-y-2">
                <p className="text-sm font-medium">
                  Selected: {selectedDate ? format(selectedDate, "PPPP") : "None"}
                </p>
                <div className="flex gap-6">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-primary"></div>
                    <span className="text-sm">Deliveries: {filteredDeliveries.length}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-secondary"></div>
                    <span className="text-sm">Collections: {filteredCollections.length}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <div className="md:col-span-2">
            <Tabs defaultValue="all">
              <div className="flex justify-between items-center mb-4">
                <TabsList>
                  <TabsTrigger value="all">All Activities</TabsTrigger>
                  <TabsTrigger value="deliveries">Deliveries</TabsTrigger>
                  <TabsTrigger value="collections">Collections</TabsTrigger>
                </TabsList>
                
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" asChild>
                    <Link to="/deliveries">
                      <Truck size={16} className="mr-2" />
                      Add Delivery
                    </Link>
                  </Button>
                  <Button variant="outline" size="sm" asChild>
                    <Link to="/collections">
                      <ArrowDown size={16} className="mr-2" />
                      Add Collection
                    </Link>
                  </Button>
                </div>
              </div>
              
              <TabsContent value="all" className="space-y-4">
                {filteredDeliveries.length === 0 && filteredCollections.length === 0 ? (
                  <div className="rounded-md bg-muted p-8 text-center">
                    <CalendarIcon size={48} className="mx-auto text-muted-foreground mb-4" />
                    <h3 className="text-lg font-medium mb-2">No Activities for This Date</h3>
                    <p className="text-muted-foreground mb-4">
                      There are no deliveries or collections scheduled for {selectedDate ? format(selectedDate, "PPPP") : "this date"}
                    </p>
                  </div>
                ) : (
                  <>
                    {filteredDeliveries.length > 0 && (
                      <Card>
                        <CardHeader className="pb-3">
                          <CardTitle className="text-lg">Deliveries</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead>Customer</TableHead>
                                <TableHead>Products</TableHead>
                                <TableHead>Status</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {filteredDeliveries.map((delivery) => (
                                <TableRow key={delivery.id}>
                                  <TableCell>{getCustomerName(delivery.customerId)}</TableCell>
                                  <TableCell>
                                    <div className="flex items-center gap-2">
                                      <Package size={16} />
                                      {delivery.jarsDelivered.cool} Cool, {delivery.jarsDelivered.pet} PET
                                    </div>
                                  </TableCell>
                                  <TableCell>
                                    <Badge
                                      variant={
                                        delivery.status === "completed" 
                                          ? "default" 
                                          : delivery.status === "pending" 
                                            ? "outline" 
                                            : "destructive"
                                      }
                                    >
                                      {delivery.status}
                                    </Badge>
                                  </TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </CardContent>
                      </Card>
                    )}
                    
                    {filteredCollections.length > 0 && (
                      <Card>
                        <CardHeader className="pb-3">
                          <CardTitle className="text-lg">Collections</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead>Customer</TableHead>
                                <TableHead>Products Returned</TableHead>
                                <TableHead>Amount</TableHead>
                                <TableHead>Status</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {filteredCollections.map((collection) => (
                                <TableRow key={collection.id}>
                                  <TableCell>{getCustomerName(collection.customerId)}</TableCell>
                                  <TableCell>
                                    <div className="flex items-center gap-2">
                                      <Package size={16} />
                                      {collection.jarsReturned.cool} Cool, {collection.jarsReturned.pet} PET
                                    </div>
                                  </TableCell>
                                  <TableCell>
                                    <div className="flex items-center gap-2">
                                      <DollarSign size={16} />
                                      ${collection.amount.toFixed(2)}
                                    </div>
                                  </TableCell>
                                  <TableCell>
                                    <Badge
                                      variant={
                                        collection.status === "completed" 
                                          ? "default" 
                                          : collection.status === "pending" 
                                            ? "outline" 
                                            : "destructive"
                                      }
                                    >
                                      {collection.status}
                                    </Badge>
                                  </TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </CardContent>
                      </Card>
                    )}
                  </>
                )}
              </TabsContent>
              
              <TabsContent value="deliveries">
                {filteredDeliveries.length === 0 ? (
                  <div className="rounded-md bg-muted p-8 text-center">
                    <Truck size={48} className="mx-auto text-muted-foreground mb-4" />
                    <h3 className="text-lg font-medium mb-2">No Deliveries for This Date</h3>
                    <p className="text-muted-foreground mb-4">
                      There are no deliveries scheduled for {selectedDate ? format(selectedDate, "PPPP") : "this date"}
                    </p>
                  </div>
                ) : (
                  <Card>
                    <CardContent className="pt-6">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Customer</TableHead>
                            <TableHead>Products</TableHead>
                            <TableHead>Status</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {filteredDeliveries.map((delivery) => (
                            <TableRow key={delivery.id}>
                              <TableCell>{getCustomerName(delivery.customerId)}</TableCell>
                              <TableCell>
                                <div className="flex items-center gap-2">
                                  <Package size={16} />
                                  {delivery.jarsDelivered.cool} Cool, {delivery.jarsDelivered.pet} PET
                                </div>
                              </TableCell>
                              <TableCell>
                                <Badge
                                  variant={
                                    delivery.status === "completed" 
                                      ? "default" 
                                      : delivery.status === "pending" 
                                        ? "outline" 
                                        : "destructive"
                                  }
                                >
                                  {delivery.status}
                                </Badge>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>
              
              <TabsContent value="collections">
                {filteredCollections.length === 0 ? (
                  <div className="rounded-md bg-muted p-8 text-center">
                    <ArrowDown size={48} className="mx-auto text-muted-foreground mb-4" />
                    <h3 className="text-lg font-medium mb-2">No Collections for This Date</h3>
                    <p className="text-muted-foreground mb-4">
                      There are no collections recorded for {selectedDate ? format(selectedDate, "PPPP") : "this date"}
                    </p>
                  </div>
                ) : (
                  <Card>
                    <CardContent className="pt-6">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Customer</TableHead>
                            <TableHead>Products Returned</TableHead>
                            <TableHead>Amount</TableHead>
                            <TableHead>Status</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {filteredCollections.map((collection) => (
                            <TableRow key={collection.id}>
                              <TableCell>{getCustomerName(collection.customerId)}</TableCell>
                              <TableCell>
                                <div className="flex items-center gap-2">
                                  <Package size={16} />
                                  {collection.jarsReturned.cool} Cool, {collection.jarsReturned.pet} PET
                                </div>
                              </TableCell>
                              <TableCell>
                                <div className="flex items-center gap-2">
                                  <DollarSign size={16} />
                                  ${collection.amount.toFixed(2)}
                                </div>
                              </TableCell>
                              <TableCell>
                                <Badge
                                  variant={
                                    collection.status === "completed" 
                                      ? "default" 
                                      : collection.status === "pending" 
                                        ? "outline" 
                                        : "destructive"
                                  }
                                >
                                  {collection.status}
                                </Badge>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </AppLayout>
  );
};

import { Link } from "react-router-dom";

export default DateView;
