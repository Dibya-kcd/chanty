import { Link, useLocation } from "react-router-dom";
import { 
  Package, 
  Users, 
  UserPlus, 
  CreditCard,
  BarChart,
  ShoppingCart,
  FileText,
  Truck
} from "lucide-react";

interface NavItemProps {
  to: string;
  icon: React.ReactNode;
  label: string;
  isActive: boolean;
}

const NavItem = ({ to, icon, label, isActive }: NavItemProps) => (
  <Link
    to={to}
    className={`flex items-center gap-3 px-3 py-2 rounded-md transition-colors ${
      isActive 
        ? "bg-primary text-primary-foreground" 
        : "hover:bg-secondary"
    }`}
  >
    {icon}
    <span>{label}</span>
  </Link>
);

interface AppLayoutProps {
  children: React.ReactNode;
}

// Add LoadingComponent to be used in other files
export const LoadingComponent = () => (
  <div className="flex items-center justify-center p-8">
    <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
  </div>
);

const AppLayout = ({ children }: AppLayoutProps) => {
  const location = useLocation();
  const currentPath = location.pathname;

  const navItems = [
    { path: "/dashboard", label: "Dashboard", icon: <BarChart size={20} /> },
    { path: "/inventory", label: "Inventory", icon: <Package size={20} /> },
    { path: "/products", label: "Products", icon: <ShoppingCart size={20} /> },
    { path: "/customers", label: "Customers", icon: <Users size={20} /> },
    { path: "/groups", label: "Groups", icon: <UserPlus size={20} /> },
    { path: "/deliveries", label: "Deliveries", icon: <Truck size={20} /> },
    { path: "/payments", label: "Payments", icon: <CreditCard size={20} /> },
    { path: "/reports", label: "Reports", icon: <FileText size={20} /> },
  ];

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside className="w-64 border-r bg-background p-4">
        <div className="mb-8">
          <Link to="/" className="flex items-center gap-2">
            <Package size={24} className="text-primary" />
            <h1 className="text-xl font-bold">Mr Water</h1>
          </Link>
        </div>
        
        <nav className="space-y-1">
          {navItems.map((item) => (
            <NavItem
              key={item.path}
              to={item.path}
              icon={item.icon}
              label={item.label}
              isActive={currentPath === item.path}
            />
          ))}
        </nav>
      </aside>
      
      {/* Main content */}
      <main className="flex-1 p-6 overflow-auto">
        {children}
      </main>
    </div>
  );
};

export default AppLayout;
