const Loading = () => {
  return (
    <div className="flex h-screen items-center justify-center">
      Loading...
    </div>
  );
};

export default Loading;