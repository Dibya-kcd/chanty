
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Customer, Product } from "@/types";
import { useContext } from "react";
import { AppContext } from "@/context/AppContext";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

interface CustomerJarSummaryProps {
  customers: Customer[];
}

const CustomerJarSummary = ({ customers }: CustomerJarSummaryProps) => {
  const { products } = useContext(AppContext);
  
  // Calculate total jars for each customer
  const customersWithTotalJars = customers.map(customer => {
    let totalJars = 0;
    
    // Sum all jars for all products
    Object.values(customer.jarsHeld).forEach(count => {
      totalJars += count;
    });
    
    return {
      ...customer,
      totalJars
    };
  });
  
  // Sort customers by total jars held (descending)
  const sortedCustomers = [...customersWithTotalJars].sort((a, b) => {
    return b.totalJars - a.totalJars;
  });

  // Calculate totals for all products and payment balances
  const productTotals: { [key: string]: number } = {};
  let totalJarsAllCustomers = 0;
  let totalBalancePositive = 0;
  let totalBalanceNegative = 0;
  
  products.forEach(product => {
    productTotals[product.id] = 0;
  });
  
  sortedCustomers.forEach(customer => {
    // Sum product totals
    Object.entries(customer.jarsHeld).forEach(([productId, count]) => {
      productTotals[productId] = (productTotals[productId] || 0) + count;
      totalJarsAllCustomers += count;
    });
    
    // Sum payment balances
    if (customer.paymentBalance) {
      if (customer.paymentBalance >= 0) {
        totalBalancePositive += customer.paymentBalance;
      } else {
        totalBalanceNegative += customer.paymentBalance;
      }
    }
  });

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle>Customer Jar Holdings</CardTitle>
        <CardDescription>
          Summary of all jars held by customers and outstanding balances
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <div className="p-4 rounded-md bg-muted">
            <div className="text-sm text-muted-foreground">Total Jars Out</div>
            <div className="text-2xl font-bold">{totalJarsAllCustomers}</div>
          </div>
          <div className="p-4 rounded-md bg-muted">
            <div className="text-sm text-muted-foreground">Credit Balance</div>
            <div className="text-2xl font-bold text-green-500">₹{totalBalancePositive.toFixed(2)}</div>
          </div>
          <div className="p-4 rounded-md bg-muted">
            <div className="text-sm text-muted-foreground">Outstanding Balance</div>
            <div className="text-2xl font-bold text-red-500">₹{Math.abs(totalBalanceNegative).toFixed(2)}</div>
          </div>
        </div>

        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Customer</TableHead>
                {products.map(product => (
                  <TableHead key={product.id} className="text-right">{product.name}</TableHead>
                ))}
                <TableHead className="text-right">Total Jars</TableHead>
                <TableHead className="text-right">Balance</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedCustomers.map((customer) => {
                // Skip customers with no jars
                if (customer.totalJars === 0) return null;
                
                return (
                  <TableRow key={customer.id}>
                    <TableCell className="font-medium">{customer.name}</TableCell>
                    {products.map(product => (
                      <TableCell key={product.id} className="text-right">
                        {customer.jarsHeld[product.id] || 0}
                      </TableCell>
                    ))}
                    <TableCell className="text-right">{customer.totalJars}</TableCell>
                    <TableCell className={`text-right ${customer.paymentBalance && customer.paymentBalance < 0 ? 'text-red-500' : 'text-green-500'}`}>
                      ₹{customer.paymentBalance?.toFixed(2) || '0.00'}
                    </TableCell>
                  </TableRow>
                );
              })}
              <TableRow className="bg-muted/50">
                <TableCell className="font-bold">TOTALS</TableCell>
                {products.map(product => (
                  <TableCell key={product.id} className="text-right font-bold">
                    {productTotals[product.id] || 0}
                  </TableCell>
                ))}
                <TableCell className="text-right font-bold">{totalJarsAllCustomers}</TableCell>
                <TableCell className="text-right font-bold">
                  ₹{(totalBalancePositive + totalBalanceNegative).toFixed(2)}
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};

export default CustomerJarSummary;
