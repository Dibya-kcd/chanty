import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from '@/components/ui/label';
import { Customer } from '@/types';
import { useToast } from '@/hooks/use-toast';

interface DeliveryDialogProps {
  customer: Customer;
  onClose: () => void;
  onSubmit: (jarsDelivered: { [productId: string]: number }, paymentReceived: number) => void;
}

const DeliveryDialog = ({ customer, onClose, onSubmit }: DeliveryDialogProps) => {
  const { toast } = useToast();
  const [petJars, setPetJars] = useState<number>(0);
  const [coolJars, setCoolJars] = useState<number>(0);
  const products = ["pet", "cool"]
  const [paymentReceived, setPaymentReceived] = useState<number>(0);

  

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();

    if (petJars < 0 || coolJars < 0 || paymentReceived < 0) {
      toast({
        title: "Error",
        description: "Please enter valid numbers (cannot be negative).",
        variant: "destructive",
      });
      return;
    }

    const jarsDelivered = products.reduce((acc, p) => ({ ...acc, [p]: p === 'pet' ? petJars : coolJars }), {})

    onSubmit(jarsDelivered, paymentReceived);
    onClose();
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Enter Delivery Details</DialogTitle>
          <DialogDescription>
            Enter the number of jars delivered and the payment received for {customer.name}.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="petJars" className="text-right">
                PET Jars
              </Label>
              <Input
                id="petJars"
                type="number"
                min="0"
                value={petJars}
                onChange={(e) => setPetJars(parseInt(e.target.value) || 0)}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="coolJars" className="text-right">
                Cool Jars
              </Label>
              <Input
                id="coolJars"
                type="number"
                min="0"
                value={coolJars}
                onChange={(e) => setCoolJars(parseInt(e.target.value) || 0)}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="paymentReceived" className="text-right">
                Payment Received
              </Label>
              <Input
                id="paymentReceived"
                type="number"
                min="0"
                value={paymentReceived}
                onChange={(e) => setPaymentReceived(parseFloat(e.target.value) || 0)}
                className="col-span-3"
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="submit">Submit</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default DeliveryDialog;