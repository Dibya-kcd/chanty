
import { useState, useEffect } from "react";
import { format, parseISO } from "date-fns";
import { supabase } from "@/lib/supabase";
import { TransactionHistoryLog } from "@/types";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import Loading from "../layout/Loading";

interface TransactionHistoryListProps {
  customerId: string;
}

export const TransactionHistoryList = ({ customerId }: TransactionHistoryListProps) => {
  const [transactions, setTransactions] = useState<TransactionHistoryLog[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTransactions = async () => {
      setLoading(true);
      try {
        const { data, error } = await supabase
          .from("transaction")
          .select("*")
          .eq("customer_id", customerId)
          .order("created_at", { ascending: false });

        if (error) throw error;
        setTransactions(data || []);
      } catch (error: any) {
        console.error("Error fetching transactions:", error.message);
      } finally {
        setLoading(false);
      }
    };

    if (customerId) {
      fetchTransactions();
    }
  }, [customerId]);

  if (loading) return <Loading />;

  if (transactions.length === 0) {
    return <div className="text-center py-8 text-muted-foreground">No transaction history found</div>;
  }

  const formatChanges = (changes: any): React.ReactNode => {
    if (!changes) return null;
    
    const elements = [];
    
    if (changes.delivery) {
      elements.push(
        <div key="delivery" className="mb-1">
          <Badge variant="outline" className="mr-2">Delivered</Badge>
          {Object.entries(changes.delivery || {}).map(([type, count]) => (
            <span key={type} className="mr-2">
              {type}: {String(count)}
            </span>
          ))}
        </div>
      );
    }
    
    if (changes.collection) {
      elements.push(
        <div key="collection" className="mb-1">
          <Badge variant="outline" className="mr-2">Collected</Badge>
          {Object.entries(changes.collection || {}).map(([type, count]) => (
            <span key={type} className="mr-2">
              {type}: {String(count)}
            </span>
          ))}
        </div>
      );
    }
    
    if (changes.payment) {
      elements.push(
        <div key="payment" className="mb-1">
          <Badge variant="outline" className="mr-2">Payment</Badge>
          ₹{changes.payment}
        </div>
      );
    }
    
    if (changes.from && changes.to) {
      elements.push(
        <div key="change" className="mb-1">
          <span className="line-through text-muted-foreground mr-2">{JSON.stringify(changes.from)}</span>
          <span>→</span>
          <span className="ml-2">{JSON.stringify(changes.to)}</span>
        </div>
      );
    }
    
    return elements.length > 0 ? elements : <span>{JSON.stringify(changes)}</span>;
  };

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Date</TableHead>
            <TableHead>Action</TableHead>
            <TableHead>Type</TableHead>
            <TableHead>Changes</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {transactions.map((transaction) => (
            <TableRow key={transaction.id}>
              <TableCell>
                {transaction.created_at ? format(parseISO(transaction.created_at), "PPP p") : "-"}
              </TableCell>
              <TableCell>
                <Badge variant={transaction.action === "created" ? "default" : transaction.action === "updated" ? "outline" : "destructive"}>
                  {transaction.action}
                </Badge>
              </TableCell>
              <TableCell>{transaction.entity_type}</TableCell>
              <TableCell>{formatChanges(transaction.changes)}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};
