
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Switch } from "@/components/ui/switch";
import { Customer } from '@/types';
import { Input } from "@/components/ui/input";

interface CustomerDetailsSectionProps {
  customer: Customer;
  name: string;
  setName: (name: string) => void;
  address: string;
  setAddress: (address: string) => void;
  contactNumber: string;
  setContactNumber: (number: string) => void;
  groupId: string | undefined;
  setGroupId: (id: string) => void;
  paymentBalance: number;
  setPaymentBalance: (balance: number) => void;
  productJars: Record<string, number>;
  setProductJars: (jars: Record<string, number>) => void;
  groups: any[];
  products: any[];
  onSave: () => void;
  isActive: boolean;
  setIsActive: (isActive: boolean) => void;
  securityDeposit: number;
  setSecurityDeposit: (deposit: number) => void;
  depositDate: string;
  setDepositDate: (date: string) => void;
  initialCoolBalance: number;
  setInitialCoolBalance: (balance: number) => void;
  initialPetBalance: number;
  setInitialPetBalance: (balance: number) => void;
  category: string;
  setCategory: (category: string) => void;
  discountRate: number;
  setDiscountRate: (rate: number) => void;
  notes: string;
  setNotes: (notes: string) => void;
}

export const CustomerDetailsSection = ({
  name,
  setName,
  setContactNumber,
  groupId,
  setGroupId,
  paymentBalance,
  setPaymentBalance,
  productJars,
  setProductJars,
  groups,
  address,
  setAddress,
  products,
  isActive,
  setIsActive,
  onSave,
  contactNumber,
  securityDeposit,
  setSecurityDeposit,
  depositDate,
  setDepositDate,
  initialCoolBalance,
  setInitialCoolBalance,
  initialPetBalance,
  setInitialPetBalance,
  category,
  setCategory,
  discountRate,
  setDiscountRate,
  notes,
  setNotes,
}: CustomerDetailsSectionProps) => {
  const handleJarCountChange = (productId: string, count: number) => {
    setProductJars({
      ...productJars,
      [productId]: count
    });
  };
      
  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="name">Customer Name</Label>
        <Input
          id="name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="address">Address</Label>
        <Input
          id="address"
          value={address}
          onChange={(e) => setAddress(e.target.value)}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="contactNumber">Contact Number</Label>
        <Input
          id="contactNumber"
          value={contactNumber}
          onChange={(e) => setContactNumber(e.target.value)}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="group">Group</Label>
        <Select value={groupId} onValueChange={setGroupId}>
          <SelectTrigger id="group">
            <SelectValue placeholder="Not assigned to a group" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="none">Not assigned</SelectItem>
            {groups.map((group) => (
              <SelectItem key={group.id} value={group.id}>
                {group.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label>Payment Balance (₹)</Label>
        <Input
          type="number"
          step="0.01"
          value={paymentBalance}
          onChange={(e) => setPaymentBalance(parseFloat(e.target.value) || 0)}
          className={paymentBalance < 0 ? 'text-red-500' : 'text-green-500'}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="isActive">Active Status</Label>
        <div className="flex items-center space-x-2">
          <Switch id="isActive" checked={isActive} onCheckedChange={setIsActive} />
          <Label htmlFor="isActive">{isActive ? 'Active' : 'Inactive'}</Label>
        </div>
      </div>

      <div className="space-y-2">
        <Label>Jars Currently Held</Label>
        <div className="space-y-3">
          {products.map((product) => (
            <div key={product.id} className="flex items-center space-x-2">
              <Label htmlFor={`product-${product.id}`} className="w-1/2">
                {product.name}:
              </Label>
              <Input
                id={`product-${product.id}`}
                type="number"
                min="0"
                value={productJars[product.id] || 0}
                onChange={(e) =>
                  handleJarCountChange(product.id, parseInt(e.target.value) || 0)
                }
                className="w-1/2"
              />
            </div>
          ))}
        </div>
      </div>

      <Button onClick={onSave} className="w-full">
      Save Changes
      </Button>
      <div className="space-y-2">
        <Label htmlFor="securityDeposit">Security Deposit (₹)</Label>
        <Input
          id="securityDeposit"
          type="number"
          className="pl-8"
          value={securityDeposit}
          onChange={(e) => setSecurityDeposit(Number(e.target.value))}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="depositDate">Deposit Date</Label>
        <Input
          id="depositDate"
          type="date"
          value={depositDate}
          onChange={(e) => setDepositDate(e.target.value)}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="initialCoolBalance">Initial Cool Balance (₹)</Label>
        <Input
          id="initialCoolBalance"
          type="number"
          className="pl-8"
          value={initialCoolBalance}
          onChange={(e) => setInitialCoolBalance(Number(e.target.value))}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="initialPetBalance">Initial Pet Balance</Label>
        <Input
          id="initialPetBalance"
          type="number"
          className="pl-8"
          value={initialPetBalance}
          onChange={(e) => setInitialPetBalance(Number(e.target.value))}
        />
      </div>
      <div className="space-y-2">
      <Label htmlFor="category">Category</Label>
        <Input
          id="category"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="notes">Notes</Label>
        <Input
          id="notes"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
        />
      </div>
     </div>
  );
};
