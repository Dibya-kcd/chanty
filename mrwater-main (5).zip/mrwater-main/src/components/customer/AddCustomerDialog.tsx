
import { useContext } from "react";
import { AppContext } from "@/context/AppContext";
import { toast } from "@/hooks/use-toast";
import CustomerForm from "./CustomerForm";

interface AddCustomerDialogProps {
  onClose?: () => void;
}

const AddCustomerDialog = ({ onClose }: AddCustomerDialogProps) => {
  const { addCustomer } = useContext(AppContext);

  const handleSubmit = (data: any) => {
    addCustomer({
      name: data.name,
      contactNumber: data.contactNumber,
      address: data.address,
      jarsHeld: {
        cool: data.initialCoolBalance || 0,
        pet: data.initialPetBalance || 0,
      },
      discountRate: data.discountRate,
      category: data.category,
      isActive: data.isActive,
      paymentBalance: 0,
      depositDate: data.depositDate ? data.depositDate.toISOString() : undefined,
      notes: data.notes
    });

    toast({
      title: "Customer added",
      description: `${data.name} has been added to your customers`,
    });

    if (onClose) {
      onClose();
    }
  };

  return (
    <CustomerForm onSubmit={handleSubmit} />
  );
};

export default AddCustomerDialog;
