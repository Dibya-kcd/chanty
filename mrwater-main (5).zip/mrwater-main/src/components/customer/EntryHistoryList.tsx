
import React from "react";
import { format } from "date-fns";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Edit } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import Loading from "@/components/layout/Loading";

interface EntryHistoryListProps {
  entries: any[];
  onEditEntry: (entry: any) => void;
  isLoading: boolean;
}

const EntryHistoryList = ({ entries, onEditEntry, isLoading }: EntryHistoryListProps) => {
  if (isLoading) {
    return <Loading />;
  }

  if (entries.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Entry History</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-center text-muted-foreground py-4">
            No entries found for this customer.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Entry History</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date & Time</TableHead>
                <TableHead>Cool Jar In</TableHead>
                <TableHead>Cool Jar Out</TableHead>
                <TableHead>Pet Jar In</TableHead>
                <TableHead>Pet Jar Out</TableHead>
                <TableHead>Collected Amount (₹)</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {entries.map((entry) => {
                // Extract jar quantities for delivery (jars in)
                const coolJarIn = entry.jars_in?.cool || 0;
                const petJarIn = entry.jars_in?.pet || 0;
                
                // Extract jar quantities for collection (jars out/returned)
                // Look in both collection object and jars_returned for flexibility
                const collectionData = entry.collection || {};
                const coolJarOut = collectionData.cool || 0;
                const petJarOut = collectionData.pet || 0;
                
                // Get payment amount from payment field
                const collectedAmount = entry.payment || (collectionData.amount || 0);
                
                return (
                  <TableRow key={entry.id}>
                    <TableCell>
                      {entry.created_at ? 
                        format(new Date(entry.created_at), "PPp") : 
                        format(new Date(entry.date || Date.now()), "PPp")}
                    </TableCell>
                    <TableCell>{coolJarIn}</TableCell>
                    <TableCell>{coolJarOut}</TableCell>
                    <TableCell>{petJarIn}</TableCell>
                    <TableCell>{petJarOut}</TableCell>
                    <TableCell>₹{collectedAmount}</TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onEditEntry(entry)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};

export default EntryHistoryList;
