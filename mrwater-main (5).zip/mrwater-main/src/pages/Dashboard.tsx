
import { useContext } from "react";
import { AppContext } from "@/context/AppContext";
import AppLayout from "@/components/layout/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Package, Truck, ArrowDown, CreditCard, Users, UserPlus } from "lucide-react";
import { Link } from "react-router-dom";

const DashboardCard = ({ 
  title, 
  value, 
  icon, 
  description,
  linkTo
}: { 
  title: string; 
  value: string | number; 
  icon: React.ReactNode;
  description?: string;
  linkTo?: string;
}) => (
  <Card>
    <CardHeader className="flex flex-row items-center justify-between pb-2">
      <CardTitle className="text-sm font-medium">{title}</CardTitle>
      <div className="p-1 bg-primary/10 rounded-full text-primary">
        {icon}
      </div>
    </CardHeader>
    <CardContent>
      <div className="text-2xl font-bold">{value}</div>
      {description && <p className="text-xs text-muted-foreground">{description}</p>}
      {linkTo && (
        <Link to={linkTo} className="text-xs text-primary hover:underline mt-2 inline-block">
          View details
        </Link>
      )}
    </CardContent>
  </Card>
);

const Dashboard = () => {
  const { 
    inventory, 
    customers, 
    groups, 
    deliveries, 
    collections, 
    payments 
  } = useContext(AppContext);
  
  // Calculate totals
  const totalInventory = inventory.cool + inventory.pet;
  const totalCustomers = customers.length;
  const totalGroups = groups.length;
  
  const todayDeliveries = deliveries.filter(d => {
    const today = new Date().toISOString().split('T')[0];
    return d.date === today;
  }).length;
  
  const pendingCollections = collections.filter(c => c.status === "pending").length;
  
  const totalPaymentsToday = payments
    .filter(p => {
      const today = new Date().toISOString().split('T')[0];
      return p.date === today && p.status === "completed";
    })
    .reduce((sum, payment) => sum + payment.amount, 0);

  // Calculate total amount due from all customers
  const totalAmountDue = customers.reduce((sum, customer) => sum + (customer.paymentBalance || 0), 0);
    
  return (
    <AppLayout>
      <div className="space-y-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
          <p className="text-muted-foreground">
            Overview of your water jar delivery business
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <DashboardCard 
            title="Total Inventory" 
            value={totalInventory}
            icon={<Package size={18} />}
            description={`${inventory.cool} Cool, ${inventory.pet} PET jars`}
            linkTo="/inventory"
          />
          <DashboardCard 
            title="Customers" 
            value={totalCustomers}
            icon={<Users size={18} />}
            linkTo="/customers"
          />
          <DashboardCard 
            title="Customer Groups" 
            value={totalGroups}
            icon={<UserPlus size={18} />}
            linkTo="/groups"
          />
          <DashboardCard 
            title="Today's Deliveries" 
            value={todayDeliveries}
            icon={<Truck size={18} />}
            linkTo="/deliveries"
          />
          <DashboardCard 
            title="Pending Collections" 
            value={pendingCollections}
            icon={<ArrowDown size={18} />}
            linkTo="/collections"
          />
          <DashboardCard 
            title="Today's Payments" 
            value={`₹${totalPaymentsToday.toFixed(2)}`}
            icon={<CreditCard size={18} />}
            linkTo="/payments"
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-8">
          <Card>
            <CardHeader>
              <CardTitle>Amount Due by Customers</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹{totalAmountDue.toFixed(2)}</div>
              <div className="space-y-2 mt-4 max-h-[300px] overflow-auto">
                {customers
                  .filter(customer => (customer.paymentBalance || 0) > 0)
                  .sort((a, b) => (b.paymentBalance || 0) - (a.paymentBalance || 0))
                  .slice(0, 10)
                  .map(customer => (
                  <div key={customer.id} className="flex justify-between items-center">
                    <Link to={`/customers/${customer.id}`} className="text-sm hover:underline">
                      {customer.name}
                    </Link>
                    <div className="text-sm font-medium">₹{(customer.paymentBalance || 0).toFixed(2)}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Recent Activities</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {deliveries.slice(0, 5).map(delivery => {
                  const customer = customers.find(c => c.id === delivery.customerId);
                  return (
                    <div key={delivery.id} className="flex items-center gap-2">
                      <Truck size={16} className="text-blue-500" />
                      <div>
                        <div className="text-sm font-medium">
                          <Link to={`/customers/${delivery.customerId}`} className="hover:underline">
                            {customer?.name || "Unknown"}
                          </Link>
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {delivery.date}
                        </div>
                      </div>
                    </div>
                  );
                })}
                
                {collections.slice(0, 3).map(collection => {
                  const customer = customers.find(c => c.id === collection.customerId);
                  return (
                    <div key={collection.id} className="flex items-center gap-2">
                      <ArrowDown size={16} className="text-green-500" />
                      <div>
                        <div className="text-sm font-medium">
                          <Link to={`/customers/${collection.customerId}`} className="hover:underline">
                            {customer?.name || "Unknown"}
                          </Link>
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {collection.date} - ₹{collection.amount.toFixed(2)}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
};

export default Dashboard;
