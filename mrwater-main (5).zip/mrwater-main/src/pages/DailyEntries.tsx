import { useParams, useNavigate, Link } from "react-router-dom";
import { useState, useEffect, useContext } from "react";
import { AppContext } from "@/context/AppContext";
import { format } from "date-fns";
import { Customer } from "@/types";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Package, ArrowDown, BadgeIndianRupee } from "lucide-react";
import Loading from "@/components/layout/Loading";
import { toast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DatePicker } from "@/components/ui/date-picker";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { supabase } from "@/lib/supabase";
import EntryHistoryList from "@/components/customer/EntryHistoryList";

const DailyEntries = () => {
  const navigate = useNavigate();
  const { customerId } = useParams<{ customerId: string }>();
  const { customers, products } = useContext(AppContext);
  
  const [date, setDate] = useState<Date>(new Date());
  const [selectedCustomerData, setSelectedCustomerData] = useState<Customer | null>(null);
  
  // Entry quantities
  const [coolInQty, setCoolInQty] = useState<number>(0);
  const [coolOutQty, setCoolOutQty] = useState<number>(0);
  const [petInQty, setPetInQty] = useState<number>(0);
  const [petOutQty, setPetOutQty] = useState<number>(0);
  
  // Financial calculations
  const [invoiceAmount, setInvoiceAmount] = useState<number>(0);
  const [collectedAmount, setCollectedAmount] = useState<number>(0);
  const [dueAmount, setDueAmount] = useState<number>(0);
  const [previousDue, setPreviousDue] = useState<number>(0);
  
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [entries, setEntries] = useState<any[]>([]);
  const [editEntryId, setEditEntryId] = useState<string | null>(null);

  // Load customer data when page loads
  useEffect(() => {
    if (!customerId) {
      toast({
        title: "Error",
        description: "No customer selected",
        variant: "destructive",
      });
      navigate("/customers");
      return;
    }
    
    const customer = customers.find(c => c.id === customerId);
    if (customer) {
      setSelectedCustomerData(customer);
      setPreviousDue(customer.paymentBalance || 0);
      setDueAmount(customer.paymentBalance || 0);
      loadEntriesForCustomer(customerId);
    } else {
      toast({
        title: "Customer not found",
        description: "The selected customer could not be found",
        variant: "destructive",
      });
      navigate("/customers");
    }
  }, [customerId, customers, navigate]);

  // Update invoice amount when quantities change
  useEffect(() => {
    let total = 0;
    
    // Only calculate for "In" quantities (deliveries)
    const coolProduct = products.find(p => p.type === "Cool water Jar");
    if (coolProduct && coolInQty > 0) {
      total += coolInQty * coolProduct.price;
    }
    
    const petProduct = products.find(p => p.type === "Pet Water Jar");
    if (petProduct && petInQty > 0) {
      total += petInQty * petProduct.price;
    }
    
    setInvoiceAmount(total);
  }, [coolInQty, petInQty, products]);

  // Update due amount when invoice or collected amount changes
  useEffect(() => {
    const calculatedDue = previousDue + invoiceAmount - collectedAmount;
    setDueAmount(calculatedDue);
  }, [previousDue, invoiceAmount, collectedAmount]);

  const loadEntriesForCustomer = async (customerId: string) => {
    setIsLoading(true);
    try {
      // Fetch all entries with complete data including collections and payments
      const { data, error } = await supabase
        .from("deliveries")
        .select("*")
        .eq("customer_id", customerId)
        .order("created_at", { ascending: false });

      if (error) throw error;
      setEntries(data || []);
    } catch (error: any) {
      toast({
        title: "Error loading entries",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async () => {
    if (!customerId || !selectedCustomerData) {
      toast({
        title: "Invalid entry",
        description: "No customer selected",
        variant: "destructive",
      });
      return;
    }

    if (coolInQty === 0 && coolOutQty === 0 && petInQty === 0 && petOutQty === 0) {
      toast({
        title: "Invalid entry",
        description: "Please enter at least one jar quantity",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      // Get current timestamp for accurate recording
      const currentTimestamp = new Date().toISOString();
      const formattedDate = format(date, 'yyyy-MM-dd');
      
      // Prepare data for insertion
      const jarsIn = {};
      
      // Set delivered jars (using lowercase keys as per database schema)
      if (coolInQty > 0) jarsIn['cool'] = coolInQty;
      if (petInQty > 0) jarsIn['pet'] = petInQty;
      
      // Prepare collection data for the transaction logs
      const collection = {};
      if (coolOutQty > 0) collection['cool'] = coolOutQty;
      if (petOutQty > 0) collection['pet'] = petOutQty;
      if (collectedAmount > 0) collection['amount'] = collectedAmount;
      
      // Calculate updated jar counts
      const customer = customers.find(c => c.id === customerId);
      if (!customer) throw new Error("Customer not found");
      
      const newJarsHeld = { ...customer.jarsHeld };
      
      // Update jar counts for IN (deliveries)
      if (coolInQty > 0) {
        newJarsHeld['cool'] = (newJarsHeld['cool'] || 0) + coolInQty;
      }
      if (petInQty > 0) {
        newJarsHeld['pet'] = (newJarsHeld['pet'] || 0) + petInQty;
      }
      
      // Update jar counts for OUT (collections)
      if (coolOutQty > 0) {
        newJarsHeld['cool'] = Math.max(0, (newJarsHeld['cool'] || 0) - coolOutQty);
      }
      if (petOutQty > 0) {
        newJarsHeld['pet'] = Math.max(0, (newJarsHeld['pet'] || 0) - petOutQty);
      }
      
      // Calculate new payment balance
      const newPaymentBalance = dueAmount;

      if (editEntryId) {
        // Update existing entry
        const { error } = await supabase
          .from("deliveries")
          .update({
            jars_in: Object.keys(jarsIn).length > 0 ? jarsIn : null,
            collection: Object.keys(collection).length > 0 ? collection : null,
            payment: collectedAmount > 0 ? collectedAmount : 0,
            updated_at: currentTimestamp
          })
          .eq("id", editEntryId);

        if (error) throw error;

        // Log the edit action
        await supabase.from("transaction").insert({
          customer_id: customerId,
          entity_type: "delivery",
          entity_id: editEntryId,
          action: "updated",
          changes: { 
            delivery: Object.keys(jarsIn).length > 0 ? jarsIn : null, 
            collection: Object.keys(collection).length > 0 ? collection : null, 
            payment: collectedAmount,
            date: formattedDate,
            timestamp: currentTimestamp
          },
          created_at: currentTimestamp
        });

      } else {
        // Create new entry with all data in a single deliveries record
        const { data, error } = await supabase
          .from("deliveries")
          .insert({
            customer_id: customerId,
            date: formattedDate,
            jars_in: Object.keys(jarsIn).length > 0 ? jarsIn : {},
            collection: Object.keys(collection).length > 0 ? collection : {},
            payment: collectedAmount > 0 ? collectedAmount : 0,
            created_at: currentTimestamp,
            updated_at: currentTimestamp
          })
          .select();

        if (error) {
          console.error("Error details:", error);
          throw error;
        }

        // Log the creation action
        if (data && data.length > 0) {
          await supabase.from("transaction").insert({
            customer_id: customerId,
            entity_type: "delivery",
            entity_id: data[0].id,
            action: "created",
            changes: { 
              delivery: Object.keys(jarsIn).length > 0 ? jarsIn : null, 
              collection: Object.keys(collection).length > 0 ? collection : null, 
              payment: collectedAmount,
              date: formattedDate,
              timestamp: currentTimestamp
            },
            created_at: currentTimestamp
          });
        }
      }

      // Update customer's jar count and payment balance
      const { error: customerUpdateError } = await supabase
        .from("customers")
        .update({
          jars_held: newJarsHeld,
          payment_balance: newPaymentBalance,
          updated_at: currentTimestamp
        })
        .eq("id", customerId);

      if (customerUpdateError) throw customerUpdateError;

      // Refresh the entries list
      await loadEntriesForCustomer(customerId);
      
      // Reset the form
      setEditEntryId(null);
      setCoolInQty(0);
      setCoolOutQty(0);
      setPetInQty(0);
      setPetOutQty(0);
      setCollectedAmount(0);
      setInvoiceAmount(0);
      
      toast({
        title: editEntryId ? "Entry updated" : "Entry created",
        description: `Successfully ${editEntryId ? "updated" : "created"} entry for ${selectedCustomerData.name}`,
      });
      
    } catch (error: any) {
      console.error("Error saving entry:", error);
      toast({
        title: "Error saving entry",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleEditEntry = (entry: any) => {
    setEditEntryId(entry.id);
    
    // Reset all quantities first
    setCoolInQty(0);
    setCoolOutQty(0);
    setPetInQty(0);
    setPetOutQty(0);
    setCollectedAmount(0);
    
    // Set jars in (delivered)
    if (entry.jars_in) {
      if (typeof entry.jars_in === 'object') {
        if ('cool' in entry.jars_in && entry.jars_in.cool !== null) {
          setCoolInQty(Number(entry.jars_in.cool) || 0);
        }
        if ('pet' in entry.jars_in && entry.jars_in.pet !== null) {
          setPetInQty(Number(entry.jars_in.pet) || 0);
        }
      }
    }
    
    // Set jars out (collected)
    if (entry.collection) {
      if (typeof entry.collection === 'object') {
        if ('cool' in entry.collection && entry.collection.cool !== null) {
          setCoolOutQty(Number(entry.collection.cool) || 0);
        }
        if ('pet' in entry.collection && entry.collection.pet !== null) {
          setPetOutQty(Number(entry.collection.pet) || 0);
        }
        if ('amount' in entry.collection && entry.collection.amount !== null) {
          setCollectedAmount(Number(entry.collection.amount) || 0);
        }
      }
    }
    
    // Set payment amount
    if (entry.payment !== null && entry.payment !== undefined) {
      setCollectedAmount(Number(entry.payment) || 0);
    }
    
    // Set invoice amount based on deliveries
    if (entry.amount !== null && entry.amount !== undefined) {
      setInvoiceAmount(Number(entry.amount) || 0);
    }
    
    // Try to parse the date
    if (entry.date) {
      try {
        setDate(new Date(entry.date));
      } catch (e) {
        console.error("Could not parse date:", e);
      }
    }
  };

  const handleCancelEdit = () => {
    setEditEntryId(null);
    setCoolInQty(0);
    setCoolOutQty(0);
    setPetInQty(0);
    setPetOutQty(0);
    setCollectedAmount(0);
  };

  if (isLoading && !selectedCustomerData) return <Loading />;

  return (
    <div className="p-4 space-y-6">
      <div className="flex justify-between items-center mb-4">
        <Link to={`/customers/${customerId}`}>
          <Button variant="link">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Customer
          </Button>
        </Link>
        <h1 className="text-2xl font-bold">
          Daily Entries {selectedCustomerData ? `for ${selectedCustomerData.name}` : ""}
        </h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>{editEntryId ? "Edit Entry" : "New Entry"}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Label htmlFor="date">Date</Label>
            <DatePicker date={date} setDate={setDate} />
          </div>
          
          <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Cool Jars Section */}
            <Card className="shadow-sm border border-muted">
              <CardHeader className="bg-muted/30 py-2">
                <CardTitle className="text-lg font-medium">Cool Jars</CardTitle>
              </CardHeader>
              <CardContent className="pt-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="coolIn" className="flex items-center">
                        <Package className="h-4 w-4 mr-1 text-blue-500" />
                        Cool In
                      </Label>
                    </div>
                    <Input 
                      id="coolIn"
                      type="number" 
                      min="0"
                      value={coolInQty} 
                      onChange={(e) => setCoolInQty(parseInt(e.target.value) || 0)} 
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="coolOut" className="flex items-center">
                        <ArrowDown className="h-4 w-4 mr-1 text-red-500" />
                        Cool Out
                      </Label>
                    </div>
                    <Input 
                      id="coolOut"
                      type="number" 
                      min="0"
                      value={coolOutQty} 
                      onChange={(e) => setCoolOutQty(parseInt(e.target.value) || 0)} 
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* PET Jars Section */}
            <Card className="shadow-sm border border-muted">
              <CardHeader className="bg-muted/30 py-2">
                <CardTitle className="text-lg font-medium">PET Jars</CardTitle>
              </CardHeader>
              <CardContent className="pt-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="petIn" className="flex items-center">
                        <Package className="h-4 w-4 mr-1 text-blue-500" />
                        Pet In
                      </Label>
                    </div>
                    <Input 
                      id="petIn"
                      type="number" 
                      min="0"
                      value={petInQty} 
                      onChange={(e) => setPetInQty(parseInt(e.target.value) || 0)} 
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="petOut" className="flex items-center">
                        <ArrowDown className="h-4 w-4 mr-1 text-red-500" />
                        Pet Out
                      </Label>
                    </div>
                    <Input 
                      id="petOut"
                      type="number" 
                      min="0"
                      value={petOutQty} 
                      onChange={(e) => setPetOutQty(parseInt(e.target.value) || 0)} 
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Financial Section */}
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="invoiceAmount" className="flex items-center">
                  <BadgeIndianRupee className="h-4 w-4 mr-1 text-green-500" />
                  Invoice Amount (₹)
                </Label>
                <Input 
                  id="invoiceAmount"
                  type="number" 
                  value={invoiceAmount} 
                  readOnly
                  className="bg-muted/30"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="collectedAmount">Collected Amount (₹)</Label>
                <Input 
                  id="collectedAmount"
                  type="number" 
                  min="0"
                  value={collectedAmount} 
                  onChange={(e) => setCollectedAmount(parseFloat(e.target.value) || 0)} 
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="dueAmount">Due Amount (₹)</Label>
                <Input 
                  id="dueAmount"
                  type="number" 
                  value={dueAmount} 
                  readOnly
                  className="bg-muted/30"
                />
              </div>
            </div>
            
            <div className="flex items-end">
              <div className="flex gap-2 justify-end w-full mt-auto">
                {editEntryId && (
                  <Button variant="outline" onClick={handleCancelEdit}>
                    Cancel
                  </Button>
                )}
                <Button 
                  onClick={handleSubmit} 
                  disabled={isLoading || (!coolInQty && !coolOutQty && !petInQty && !petOutQty)}
                  className="w-full"
                >
                  {editEntryId ? "Update Entry" : "Save Entry"}
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {selectedCustomerData && (
        <EntryHistoryList 
          entries={entries} 
          onEditEntry={handleEditEntry}
          isLoading={isLoading}
        />
      )}
    </div>
  );
};

export default DailyEntries;
