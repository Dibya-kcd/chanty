
import { useState, useEffect, useContext } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { AppContext } from "@/context/AppContext";
import { Group } from "@/types";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";
import {
  ArrowLeft,
  Save,
  Trash,
  UserPlus,
  UserMinus,
  Users,
} from "lucide-react";
import Loading from "@/components/layout/Loading";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

const GroupDetail = () => {
  const { groupId } = useParams<{ groupId: string }>();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const { groups, customers, updateGroup, removeGroup, assignCustomerToGroup, removeCustomerFromGroup } = useContext(AppContext);
  
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [collectionDay, setCollectionDay] = useState("");
  const [amountDue, setAmountDue] = useState<number>(0);
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>("");
  
  const collectableDays = [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
  ];

  // Get group and its members
  useEffect(() => {
    if (!groupId) return;

    const group = groups.find((g) => g.id === groupId);
    if (group) {
      setName(group.name);
      setDescription(group.description || "");
      setCollectionDay(group.collectionDay || "");
      setAmountDue(group.amountDue || 0);
      setIsLoading(false);
    } else {
      toast({
        title: "Group not found",
        description: "The requested group could not be found.",
        variant: "destructive",
      });
      navigate("/groups");
    }
  }, [groupId, groups, navigate]);

  const groupMembers = customers.filter((customer) => customer.groupId === groupId);
  const availableCustomers = customers.filter((customer) => !customer.groupId || customer.groupId !== groupId);

  const handleSave = async () => {
    if (!groupId) return;
    
    try {
      await updateGroup(groupId, {
        name,
        description,
        collectionDay,
        amountDue,
      });
      
      toast({
        title: "Group updated",
        description: "The group has been successfully updated.",
      });
    } catch (error) {
      console.error("Error updating group:", error);
      toast({
        title: "Error",
        description: "Failed to update group. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleDelete = async () => {
    if (!groupId) return;
    
    if (window.confirm("Are you sure you want to delete this group? This cannot be undone.")) {
      try {
        // Remove all customers from the group first
        for (const member of groupMembers) {
          await removeCustomerFromGroup(member.id);
        }
        
        // Then delete the group
        await removeGroup(groupId);
        
        toast({
          title: "Group deleted",
          description: "The group has been successfully deleted.",
        });
        
        navigate("/groups");
      } catch (error) {
        console.error("Error deleting group:", error);
        toast({
          title: "Error",
          description: "Failed to delete group. Please try again.",
          variant: "destructive",
        });
      }
    }
  };

  const handleAddMember = async () => {
    if (!selectedCustomerId || !groupId) return;
    
    try {
      await assignCustomerToGroup(selectedCustomerId, groupId);
      
      toast({
        title: "Member added",
        description: "The customer has been added to this group.",
      });
      
      setSelectedCustomerId("");
    } catch (error) {
      console.error("Error adding member:", error);
      toast({
        title: "Error",
        description: "Failed to add member. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleRemoveMember = async (customerId: string) => {
    try {
      await removeCustomerFromGroup(customerId);
      
      toast({
        title: "Member removed",
        description: "The customer has been removed from this group.",
      });
    } catch (error) {
      console.error("Error removing member:", error);
      toast({
        title: "Error",
        description: "Failed to remove member. Please try again.",
        variant: "destructive",
      });
    }
  };

  if (isLoading) return <Loading />;

  return (
    <div className="p-4 space-y-6">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Link to="/groups">
            <Button variant="ghost">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Groups
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">{name}</h1>
        </div>
        <Button variant="destructive" onClick={handleDelete}>
          <Trash className="h-4 w-4 mr-2" />
          Delete Group
        </Button>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Group Details */}
        <Card>
          <CardHeader>
            <CardTitle>Group Details</CardTitle>
            <CardDescription>Edit group information</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Group Name</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter group name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Enter group description"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="collection-day">Collection Day</Label>
              <Select
                value={collectionDay}
                onValueChange={setCollectionDay}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select collection day" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">None</SelectItem>
                  {collectableDays.map((day) => (
                    <SelectItem key={day} value={day}>
                      {day}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="amount-due">Amount Due (₹)</Label>
              <Input
                id="amount-due"
                type="number"
                value={amountDue}
                onChange={(e) => setAmountDue(Number(e.target.value))}
                placeholder="0.00"
              />
            </div>
            <Button onClick={handleSave} className="w-full">
              <Save className="h-4 w-4 mr-2" />
              Save Changes
            </Button>
          </CardContent>
        </Card>

        {/* Group Members */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Group Members</CardTitle>
              <CardDescription>
                {groupMembers.length} member{groupMembers.length !== 1 ? "s" : ""}
              </CardDescription>
            </div>
            
            <Dialog>
              <DialogTrigger asChild>
                <Button>
                  <UserPlus className="h-4 w-4 mr-2" />
                  Add Member
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add Member to Group</DialogTitle>
                </DialogHeader>
                <div className="py-4 space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="customer">Select Customer</Label>
                    <Select
                      value={selectedCustomerId}
                      onValueChange={setSelectedCustomerId}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select a customer" />
                      </SelectTrigger>
                      <SelectContent>
                        {availableCustomers.map((customer) => (
                          <SelectItem key={customer.id} value={customer.id}>
                            {customer.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <Button 
                    onClick={handleAddMember} 
                    className="w-full" 
                    disabled={!selectedCustomerId}
                  >
                    <UserPlus className="h-4 w-4 mr-2" />
                    Add to Group
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </CardHeader>
          <CardContent>
            {groupMembers.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Customer</TableHead>
                    <TableHead>Balance</TableHead>
                    <TableHead>Jars Held</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {groupMembers.map((member) => (
                    <TableRow key={member.id}>
                      <TableCell>
                        <Link to={`/customers/${member.id}`}>{member.name}</Link>
                      </TableCell>
                      <TableCell>₹{member.paymentBalance || 0}</TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          {Object.entries(member.jarsHeld || {}).map(([jarType, count]) => (
                            <Badge key={jarType} variant="outline">
                              {jarType}: {count}
                            </Badge>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleRemoveMember(member.id)}
                        >
                          <UserMinus className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Users className="mx-auto h-12 w-12 opacity-20" />
                <p className="mt-2">No members in this group yet.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default GroupDetail;
