import { useContext, useState } from "react";
import { AppContext } from "@/context/AppContext";  
import AppLayout, { LoadingComponent } from "@/components/layout/AppLayout";
import { useNavigate } from "react-router-dom"; 
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  UserPlus,
  Search,
  Truck
} from "lucide-react";
import AddCustomerDialog from "@/components/customer/AddCustomerDialog";
import CustomerDetailsDialog from "@/components/customer/CustomerDetailsDialog";
import DeliveryDialog from "@/components/customer/DeliveryDialog";
import { Customer } from "@/types";
import { Badge } from "@/components/ui/badge";

const CustomerRow = ({ customer, onEdit }: { customer: Customer; onEdit: () => void }) => {
  const navigate = useNavigate();
  const onNavigate = () => {
    navigate(`/customers/${customer.id}/daily-entries`);
  };
  return (
    <TableRow>
      <TableCell className="font-medium">
        <button onClick={onEdit} className="text-left hover:underline">
          {customer.name}
        </button>
      </TableCell>      
      <TableCell>
        <div className="flex flex-col gap-1">
          <div className="text-sm">PET: {customer.jarsHeld.pet || 0}</div>
          <div className="text-sm">Cool: {customer.jarsHeld.cool || 0}</div>
        </div>
      </TableCell>
      <TableCell>
        <div className={`${customer.paymentBalance && customer.paymentBalance < 0 ? 'text-red-500' : 'text-green-500'}`}>
          ₹{customer.paymentBalance?.toFixed(2) || '0.00'}
        </div>
      </TableCell>
      <TableCell>
        <Badge variant={customer.isActive ? "outline" : "destructive"}>
          {customer.isActive ? "Active" : "Inactive"}
        </Badge>
      </TableCell>
      <TableCell className="text-right">
        <Button size="sm" onClick={onNavigate} className="p-1.5">
          <Truck className="h-4 w-4" />
          <span className="sr-only">Delivery</span>
        </Button>
      </TableCell>
    </TableRow>
  ); 
};

const Customers = () => {
  // Get the addDailyEntry function from the AppContext
  const { customers, loading, addDailyEntry } = useContext(AppContext); 
  const [searchQuery, setSearchQuery] = useState("");
  const [showAddCustomer, setShowAddCustomer] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [showDeliveryDialog, setShowDeliveryDialog] = useState(false);
  const [selectedCustomerForDelivery, setSelectedCustomerForDelivery] = useState<Customer | null>(null);
  
  const filteredCustomers = customers.filter(customer => 
    customer.name.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Customers</h2>
            <p className="text-muted-foreground">
              Manage your water jar delivery customers
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button onClick={() => setShowAddCustomer(true)}>
              <UserPlus size={16} className="mr-2" />
              Add Customer
            </Button>
          </div>
          
        </div>
        {loading && ( // Show loading indicator when loading is true
          <div className="w-full h-full flex items-center justify-center">
            <LoadingComponent />
          </div>
        )}
        
        <div className="space-x-2">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search customers by name..."
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        {!loading && filteredCustomers.length === 0 ? (
          <div className="rounded-md bg-muted p-8 text-center">
            <UserPlus size={48} className="mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">No Customers Found</h3>
            <p className="text-muted-foreground mb-4">
              {searchQuery ? "No customers match your search. Would you like to add a new customer?" : "Add your first customer to get started"}
            </p>
            <Button onClick={() => setShowAddCustomer(true)}>
              <UserPlus size={16} className="mr-2" />
              Add New Customer
            </Button>
          </div>
        ) : !loading && (
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Customer Name</TableHead>
                  <TableHead>Balance Jars</TableHead>
                  <TableHead>Payment Balance</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredCustomers.map((customer) => (
                  <CustomerRow 
                    key={customer.id}
                    customer={customer}
                    onEdit={() => setSelectedCustomer(customer)}
                  />
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>
      
      {/* Add Customer Dialog */}
      <Dialog open={showAddCustomer} onOpenChange={setShowAddCustomer}>
        <DialogContent>
            <DialogHeader>
                <DialogTitle>Add New Customer</DialogTitle>
                <DialogDescription>Add a new customer to your water jar delivery service</DialogDescription>
            </DialogHeader><AddCustomerDialog onClose={() => setShowAddCustomer(false)} />
        </DialogContent>
      </Dialog>

      {/* Customer Details Dialog */}
      <Dialog open={!!selectedCustomer} onOpenChange={(open) => !open && setSelectedCustomer(null)}>
        <DialogContent className="max-w-2xl">
          {selectedCustomer && (
            <CustomerDetailsDialog 
            customer={selectedCustomer}
            onClose={() => setSelectedCustomer(null)}
            />
          )}
        </DialogContent>
      </Dialog>
      
      {/* Delivery Dialog */}
      <Dialog open={showDeliveryDialog} onOpenChange={setShowDeliveryDialog}>
      <DialogContent className="sm:max-w-[425px]">
          {selectedCustomerForDelivery && (
            <DeliveryDialog
              customer={selectedCustomerForDelivery}
              onClose={() => setShowDeliveryDialog(false)}
              onSubmit={(jarsDelivered, paymentReceived) => {
                if (selectedCustomerForDelivery) {
                  const entry = {
                    delivery: jarsDelivered,
                    payment: paymentReceived > 0 ? {
                      amount: paymentReceived,
                      paymentMethod: 'cash' as 'cash' | 'card' | 'bank_transfer'
                    } : undefined
                  };
                  
                  addDailyEntry(selectedCustomerForDelivery.id, entry);
                }
                setShowDeliveryDialog(false);
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
};

export default Customers;
