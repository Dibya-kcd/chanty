
import { useContext, useState } from "react";
import { AppContext } from "@/context/AppContext";
import AppLayout from "@/components/layout/AppLayout";
import { format, parseISO } from "date-fns";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Package, ArrowDown, Filter } from "lucide-react";
import { Link } from "react-router-dom";

const Entries = () => {
  const { customers, products, deliveries, collections } = useContext(AppContext);
  const [searchQuery, setSearchQuery] = useState("");
  const [customerFilter, setCustomerFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  
  // Combine deliveries and collections for unified view
  const deliveryEntries = deliveries.map(delivery => ({
    id: delivery.id,
    type: "delivery",
    customerId: delivery.customerId,
    date: delivery.date,
    status: delivery.status,
    jars: delivery.jarsDelivered,
    amount: 0 // Deliveries don't have amount
  }));
  
  const collectionEntries = collections.map(collection => ({
    id: collection.id,
    type: "collection",
    customerId: collection.customerId,
    date: collection.date,
    status: collection.status,
    jars: collection.jarsReturned,
    amount: collection.amount
  }));
  
  // Combine all entries and sort by date (newest first)
  const allEntries = [...deliveryEntries, ...collectionEntries].sort((a, b) => {
    return new Date(b.date).getTime() - new Date(a.date).getTime();
  });
  
  // Filter entries based on search, customer, and status
  const filteredEntries = allEntries.filter(entry => {
    const customer = customers.find(c => c.id === entry.customerId);
    const customerName = customer?.name || "";
    
    const matchesSearch = customerName.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCustomer = customerFilter === "all" || entry.customerId === customerFilter;
    const matchesStatus = statusFilter === "all" || entry.status === statusFilter;
    
    return matchesSearch && matchesCustomer && matchesStatus;
  });
  
  // Filter entries by type for tab display
  const deliveryOnlyEntries = filteredEntries.filter(entry => entry.type === "delivery");
  const collectionOnlyEntries = filteredEntries.filter(entry => entry.type === "collection");
  
  const renderEntryRow = (entry) => {
    const customer = customers.find(c => c.id === entry.customerId);
    
    return (
      <TableRow key={`${entry.type}-${entry.id}`}>
        <TableCell className="font-medium">
          <Link to={`/customers/${entry.customerId}`} className="hover:underline">
            {customer?.name || "Unknown Customer"}
          </Link>
        </TableCell>
        <TableCell>{format(parseISO(entry.date), "PPP")}</TableCell>
        <TableCell>
          <Badge variant={entry.type === "delivery" ? "default" : "secondary"}>
            {entry.type === "delivery" ? "Delivery" : "Collection"}
          </Badge>
        </TableCell>
        <TableCell>
          <div className="flex flex-col gap-1">
            {products.map(product => {
              const count = entry.jars[product.id] || 0;
              if (count === 0) return null;
              return (
                <div key={product.id} className="text-sm">
                  {product.name}: {count}
                </div>
              );
            })}
          </div>
        </TableCell>
        {entry.type === "collection" && (
          <TableCell>₹{entry.amount.toFixed(2)}</TableCell>
        )}
        {entry.type === "delivery" && (
          <TableCell>-</TableCell>
        )}
        <TableCell>
          <Badge variant={entry.status === "completed" ? "outline" : "secondary"}>
            {entry.status}
          </Badge>
        </TableCell>
      </TableRow>
    );
  };
  
  return (
    <AppLayout>
      <div className="space-y-6">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Entries</h2>
          <p className="text-muted-foreground">
            View all deliveries and collections in one place
          </p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search by customer name..."
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          <div className="flex items-center gap-2">
            <Select value={customerFilter} onValueChange={setCustomerFilter}>
              <SelectTrigger className="w-[160px]">
                <SelectValue placeholder="All Customers" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Customers</SelectItem>
                {customers.map(customer => (
                  <SelectItem key={customer.id} value={customer.id}>
                    {customer.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="All Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Delivery and Collection Entries</CardTitle>
            <CardDescription>
              View and filter all jar movement activities
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="all">
              <TabsList className="mb-4">
                <TabsTrigger value="all">All Entries</TabsTrigger>
                <TabsTrigger value="deliveries">
                  <Package size={16} className="mr-2" />
                  Deliveries
                </TabsTrigger>
                <TabsTrigger value="collections">
                  <ArrowDown size={16} className="mr-2" />
                  Collections
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="all">
                {filteredEntries.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    No entries match your search criteria.
                  </div>
                ) : (
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Customer</TableHead>
                          <TableHead>Date</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Jars</TableHead>
                          <TableHead>Amount</TableHead>
                          <TableHead>Status</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredEntries.map(renderEntryRow)}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="deliveries">
                {deliveryOnlyEntries.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    No deliveries match your search criteria.
                  </div>
                ) : (
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Customer</TableHead>
                          <TableHead>Date</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Jars</TableHead>
                          <TableHead>Amount</TableHead>
                          <TableHead>Status</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {deliveryOnlyEntries.map(renderEntryRow)}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="collections">
                {collectionOnlyEntries.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    No collections match your search criteria.
                  </div>
                ) : (
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Customer</TableHead>
                          <TableHead>Date</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Jars</TableHead>
                          <TableHead>Amount</TableHead>
                          <TableHead>Status</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {collectionOnlyEntries.map(renderEntryRow)}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
};

export default Entries;
