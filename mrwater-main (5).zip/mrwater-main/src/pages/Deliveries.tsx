
import { useContext, useState } from "react";
import { AppContext } from "@/context/AppContext";
import AppLayout from "@/components/layout/AppLayout";
import { format, parseISO } from "date-fns";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Search, Truck, UserPlus } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import AddCustomerDialog from "@/components/customer/AddCustomerDialog";

const Deliveries = () => {
  const { deliveries, customers } = useContext(AppContext);
  const [searchQuery, setSearchQuery] = useState("");
  const [customerFilter, setCustomerFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [showAddCustomer, setShowAddCustomer] = useState(false);
  const navigate = useNavigate();
  
  // Filter deliveries based on search, customer, and status
  const filteredDeliveries = deliveries.filter(delivery => {
    const customer = customers.find(c => c.id === delivery.customerId);
    const customerName = customer?.name || "";
    
    const matchesSearch = customerName.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCustomer = customerFilter === "all" || delivery.customerId === customerFilter;
    const matchesStatus = statusFilter === "all" || delivery.status === statusFilter;
    
    return matchesSearch && matchesCustomer && matchesStatus;
  });

  // Handle click on customer name
  const handleCustomerClick = (customerId: string) => {
    navigate(`/customers/${customerId}`);
  };

  return (
    <AppLayout>
      <div className="space-y-6">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Deliveries</h2>
          <p className="text-muted-foreground">
            Manage and track all jar deliveries
          </p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search by customer name..."
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          <div className="flex items-center gap-2">
            <Select value={customerFilter} onValueChange={setCustomerFilter}>
              <SelectTrigger className="w-[160px]">
                <SelectValue placeholder="All Customers" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Customers</SelectItem>
                {customers.map(customer => (
                  <SelectItem key={customer.id} value={customer.id}>
                    {customer.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="All Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle>Delivery Entries</CardTitle>
            <CardDescription>
              View and manage all jar delivery activities
            </CardDescription>
          </CardHeader>
          <CardContent>
            {filteredDeliveries.length === 0 && searchQuery && (
              <div className="text-center py-8">
                <p className="text-muted-foreground mb-4">
                  No deliveries found for "{searchQuery}". Would you like to add a new customer?
                </p>
                <Button onClick={() => setShowAddCustomer(true)}>
                  <UserPlus size={16} className="mr-2" />
                  Add New Customer
                </Button>
              </div>
            )}
            
            {filteredDeliveries.length === 0 && !searchQuery ? (
              <div className="text-center py-8 text-muted-foreground">
                No deliveries recorded yet.
              </div>
            ) : (
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Customer</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Jars Delivered</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredDeliveries.map(delivery => {
                      const customer = customers.find(c => c.id === delivery.customerId);
                      return (
                        <TableRow key={delivery.id}>
                          <TableCell>
                            <button
                              onClick={() => handleCustomerClick(delivery.customerId)}
                              className="hover:underline text-left font-medium"
                            >
                              {customer?.name || "Unknown Customer"}
                            </button>
                          </TableCell>
                          <TableCell>{format(parseISO(delivery.date), "PPP")}</TableCell>
                          <TableCell>
                            <div className="flex flex-col gap-1">                              
                              {delivery.jarsDelivered && Object.entries(delivery.jarsDelivered).length > 0 ? (
                                Object.entries(delivery.jarsDelivered).map(([type, count]) => (
                                  <div key={type} className="text-sm">
                                    {type}: {count}
                                  </div>
                                ))
                              ) : (
                                <div className="text-sm">No jars delivered</div>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant={delivery.status === "completed" ? "outline" : "secondary"}>
                              {delivery.status}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => navigate(`/customers/${delivery.customerId}/daily-entries`)}
                            >
                              <Truck size={16} className="mr-2" />
                              View Entries
                            </Button>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      
      {showAddCustomer && (
        <Dialog open={showAddCustomer} onOpenChange={setShowAddCustomer}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Customer</DialogTitle>
              <DialogDescription>
                Add a new customer to your water jar delivery service
              </DialogDescription>
            </DialogHeader>
            
            <AddCustomerDialog onClose={() => setShowAddCustomer(false)} />
          </DialogContent>
        </Dialog>
      )}
    </AppLayout>
  );
};

export default Deliveries;
