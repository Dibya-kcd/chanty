export interface Customer {
  id: string;
  name: string;
  jarsHeld: {
    [productId: string]: number;
  };
  address?: string;
  contactNumber?: string;
  groupId?: string;
  paymentBalance?: number;
  depositDate?: string;
  discountRate?: number;
  notes?: string;
  isActive?: boolean;
  category?: string;
  securityDeposit?: number;
  initialCoolBalance?: number;
  initialPetBalance?: number;
}

export interface Inventory {
  cool: number;
  pet: number;
}

export interface Group {
  id: string;
  name: string;
  description?: string;
  collectionDay?: string;
  amountDue?: number;
}

export interface Delivery {
  id: string;
  customerId: string;
  date: string;
  jarsDelivered: {
    cool?: number;
    pet?: number;
    [productId: string]: number | undefined;
  };
  status: 'pending' | 'completed' | 'cancelled';
}

export interface Collection {
  id: string;
  customerId: string;
  date: string;
  amount: number;
  jarsReturned: {
    cool?: number;
    pet?: number;
    [productId: string]: number | undefined;
  };
  status: 'pending' | 'completed' | 'cancelled';
}

export interface Payment {
  id: string;
  customerId: string;
  date: string;
  amount: number;
  paymentMethod: 'cash' | 'card' | 'bank_transfer';
  status: 'pending' | 'completed' | 'failed';
}

export interface Product {
  id: string;
  name: string;
  type: string;
  price: number;
  description?: string;
  inStock: number;
}

export interface CustomerDailyEntry {
  date: string;
  delivery?: {
    [productId: string]: number;
  };
  collection?: {
    [productId: string]: number;
    amount: number;
  };
  payment?: {
    amount: number;
    paymentMethod: 'cash' | 'card' | 'bank_transfer';
  };
}

export interface TransactionHistoryLog {
  id: string;
  customer_id: string;
  entity_type: string;
  entity_id: string;
  action: string;
  changes: any;
  created_at: string;
}
