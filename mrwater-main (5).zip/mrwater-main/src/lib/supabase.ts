
import { supabase } from "@/integrations/supabase/client";

export { supabase };
