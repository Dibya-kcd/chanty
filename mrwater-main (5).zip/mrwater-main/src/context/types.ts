
import {
  Customer,
  Inventory,
  Delivery,
  Collection,
  Payment,
  Group,
  Product,
  CustomerDailyEntry,
} from "@/types";

export interface AppContextType {
  inventory: Inventory;
  customers: Customer[];
  groups: Group[];
  deliveries: Delivery[];
  collections: Collection[];
  payments: Payment[];
  products: Product[];
  loading: boolean; // Added loading property

  updateJarInventory: (jars: { cool: number; pet: number }) => void;
  addCustomer: (customer: Omit<Customer, "id">) => Promise<void>;
  updateCustomer: (id: string, customer: Partial<Customer>) => Promise<void>;
  removeCustomer: (id: string) => Promise<void>;
  
  addGroup: (group: Omit<Group, "id">) => Promise<void>;
  updateGroup: (id: string, group: Partial<Group>) => Promise<void>;
  removeGroup: (id: string) => Promise<void>;
  
  assignCustomerToGroup: (customerId: string, groupId: string) => Promise<void>;
  removeCustomerFromGroup: (customerId: string) => Promise<void>;
  
  addDelivery: (delivery: Omit<Delivery, "id">) => Promise<void>;
  updateDelivery: (id: string, delivery: Partial<Delivery>) => Promise<void>;
  removeDelivery: (id: string) => Promise<void>;
  
  addCollection: (collection: Omit<Collection, "id">) => Promise<void>;
  updateCollection: (id: string, collection: Partial<Collection>) => Promise<void>;
  removeCollection: (id: string) => Promise<void>;
  
  addPayment: (payment: Omit<Payment, "id">) => Promise<void>;
  updatePayment: (id: string, payment: Partial<Payment>) => Promise<void>;
  removePayment: (id: string) => Promise<void>;
  
  addProduct: (product: Omit<Product, "id">) => Promise<void>;
  updateProduct: (id: string, product: Partial<Product>) => Promise<void>;
  removeProduct: (id: string) => Promise<void>;
  
  addDailyEntry: (
    customerId: string,
    entry: {
      delivery?: { [productId: string]: number };
      collection?: { [productId: string]: number; amount?: number };
      payment?: { amount: number; paymentMethod: "cash" | "card" | "bank_transfer" };
      date?: string;
    }
  ) => Promise<void>;
}
