
import React, { createContext, ReactNode } from "react";
import { AppContextType } from "./types";
import { useInventory } from "./hooks/useInventory";
import { useCustomers } from "./hooks/useCustomers";
import { useDeliveries } from "./hooks/useDeliveries";
import { useCollections } from "./hooks/useCollections";
import { usePayments } from "./hooks/usePayments";
import { useProducts } from "./hooks/useProducts"; 
import { useGroups } from "./hooks/useGroups";

// Create a context with default values
export const AppContext = createContext<AppContextType>({} as AppContextType);

interface AppProviderProps {
  children: ReactNode;
}

export const AppProvider = ({ children }: AppProviderProps) => {
  // Use our custom hooks
  const { inventory, updateJarInventory } = useInventory();
  const { 
    customers, 
    addCustomer, 
    updateCustomer, 
    removeCustomer, 
    assignCustomerToGroup, 
    removeCustomerFromGroup,
    addDailyEntry,
    loading
  } = useCustomers();
  
  const { groups, addGroup, updateGroup, removeGroup } = useGroups();
  const { deliveries, addDelivery, updateDelivery, removeDelivery } = useDeliveries();
  const { collections, addCollection, updateCollection, removeCollection } = useCollections();
  const { payments, addPayment, updatePayment, removePayment } = usePayments();
  const { products, addProduct, updateProduct, removeProduct } = useProducts();

  // Provide the context values to children
  return (
    <AppContext.Provider
      value={{
        inventory,
        customers,
        groups,
        deliveries,
        collections,
        payments,
        products,
        loading,
        updateJarInventory,
        addCustomer,
        updateCustomer,
        removeCustomer,
        addGroup,
        updateGroup,
        removeGroup,
        assignCustomerToGroup,
        removeCustomerFromGroup,
        addDelivery,
        updateDelivery,
        removeDelivery,
        addCollection,
        updateCollection,
        removeCollection,
        addPayment,
        updatePayment,
        removePayment,
        addProduct,
        updateProduct,
        removeProduct,
        addDailyEntry
      }}
    >
      {children}
    </AppContext.Provider>
  );
};
