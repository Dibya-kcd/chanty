
import { useState, useEffect } from "react";
import { Delivery } from "@/types";
import { supabase } from "@/lib/supabase";
import { useToast } from "@/hooks/use-toast";

export function useDeliveries() {
  const [deliveries, setDeliveries] = useState<Delivery[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const { toast } = useToast();

  // Fetch deliveries from Supabase
  useEffect(() => {
    const fetchDeliveries = async () => {
      try {
        setLoading(true);
        const { data, error } = await supabase
          .from('deliveries')
          .select('*');

        if (error) {
          throw error;
        }

        if (data) {
          const formattedDeliveries: Delivery[] = data.map((delivery) => ({
            id: delivery.id,
            customerId: delivery.customer_id,
            date: delivery.date,
            // Map jars_in to jarsDelivered for frontend consistency
            jarsDelivered: delivery.jars_in as { [productId: string]: number },
            // Default status to 'completed' since there's no status field in DB
            status: 'completed',
          }));

          setDeliveries(formattedDeliveries);
        }
      } catch (error: any) {
        console.error('Error fetching deliveries:', error.message);
        toast({
          title: "Error fetching deliveries",
          description: error.message,
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    fetchDeliveries();

    // Subscribe to changes in the deliveries table
    const subscription = supabase
      .channel('public:deliveries')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'deliveries' }, async () => {
        await fetchDeliveries();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(subscription);
    };
  }, [toast]);

  // Delivery management functions
  const addDelivery = async (delivery: Omit<Delivery, "id">) => {
    try {
      // Update Supabase
      const { data, error } = await supabase
        .from('deliveries')
        .insert([{
          customer_id: delivery.customerId,
          date: delivery.date,          
          jars_in: delivery.jarsDelivered || {}, // Map jarsDelivered to jars_in for backend consistency
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }])
        .select()
        .single();

      if (error) throw error;

      if (data) {
        const newDelivery: Delivery = {
          id: data.id,
          customerId: data.customer_id,
          date: data.date,
          jarsDelivered: data.jars_in as { [productId: string]: number },
          status: 'completed', // Default status
        };

        setDeliveries((prev) => [...prev, newDelivery]);
      }
      
      // Update customer jar counts if needed
      const customer = await supabase.from("customers").select("*").eq("id", delivery.customerId).single();
      
      if (customer.data && customer.data.jars_held) {
        const jarsHeld = customer.data.jars_held || {};
        // Use type assertion for jarsHeld to avoid spread type error
        const newJarsHeld = { ...(jarsHeld as object) } as Record<string, number>;
        
        if (delivery.jarsDelivered) {
          for (const productId in delivery.jarsDelivered) {
            const currentCount = newJarsHeld[productId] || 0;
            const deliveryCount = delivery.jarsDelivered[productId] || 0;
            newJarsHeld[productId] = currentCount + deliveryCount;
          }
        }
        
        await supabase
          .from('customers')
          .update({ 
            jars_held: newJarsHeld,
            updated_at: new Date().toISOString() 
          })
          .eq('id', delivery.customerId);
      }
      
      return Promise.resolve();
    } catch (error: any) {
      console.error('Error adding delivery:', error.message);
      toast({
        title: "Error adding delivery",
        description: error.message,
        variant: "destructive"
      });
      return Promise.reject(error);
    }
  };

  const updateDelivery = async (id: string, delivery: Partial<Delivery>) => {
    try {
      const oldDelivery = deliveries.find(d => d.id === id);
      if (!oldDelivery) throw new Error("Delivery not found");
      
      // Convert from client model to database model
      const dbDelivery: any = {};
      if (delivery.customerId !== undefined) dbDelivery.customer_id = delivery.customerId;
      if (delivery.date !== undefined) dbDelivery.date = delivery.date;
      if (delivery.jarsDelivered !== undefined) dbDelivery.jars_in = delivery.jarsDelivered;
      dbDelivery.updated_at = new Date().toISOString();

      const { error } = await supabase
        .from('deliveries')
        .update(dbDelivery)
        .eq('id', id);

      if (error) throw error;

      // Update local state
      setDeliveries((prev) => 
        prev.map((d) => (d.id === id ? { ...d, ...delivery } : d))
      );
      
      // Update customer jar counts if needed
      const customer = await supabase.from("customers").select("*").eq("id", oldDelivery.customerId).single();
      
      if (customer.data && customer.data.jars_held && delivery.jarsDelivered) {
        const jarsHeld = customer.data.jars_held || {};
        // Use type assertion for jarsHeld to avoid spread type error
        const newJarsHeld = { ...(jarsHeld as object) } as Record<string, number>;
        
        // Remove old delivery quantities
        if (oldDelivery.jarsDelivered) {
          for (const productId in oldDelivery.jarsDelivered) {
            const currentCount = newJarsHeld[productId] || 0;
            const oldCount = oldDelivery.jarsDelivered[productId] || 0;
            newJarsHeld[productId] = Math.max(0, currentCount - oldCount);
          }
        }
        
        // Add new delivery quantities
        if (delivery.jarsDelivered) {
          for (const productId in delivery.jarsDelivered) {
            const currentCount = newJarsHeld[productId] || 0;
            const newCount = delivery.jarsDelivered[productId] || 0;
            newJarsHeld[productId] = currentCount + newCount;
          }
        }
        
        await supabase
          .from('customers')
          .update({ 
            jars_held: newJarsHeld,
            updated_at: new Date().toISOString() 
          })
          .eq('id', oldDelivery.customerId);
      }
      
      return Promise.resolve();
    } catch (error: any) {
      console.error('Error updating delivery:', error.message);
      toast({
        title: "Error updating delivery",
        description: error.message,
        variant: "destructive",
      });
      return Promise.reject(error);
    }
  };

  const removeDelivery = async (id: string) => {
    try {
      const delivery = deliveries.find(d => d.id === id);
      if (!delivery) throw new Error("Delivery not found");
      
      const { error } = await supabase
        .from('deliveries')
        .delete()
        .eq('id', id);

      if (error) throw error;

      // Update local state
      setDeliveries((prev) => prev.filter((d) => d.id !== id));
      
      // Update customer jar counts
      const customer = await supabase.from("customers").select("*").eq("id", delivery.customerId).single();
      
      if (customer.data && customer.data.jars_held) {
        const jarsHeld = customer.data.jars_held || {};
        // Use type assertion for jarsHeld to avoid spread type error
        const newJarsHeld = { ...(jarsHeld as object) } as Record<string, number>;
        
        if (delivery.jarsDelivered) {
          for (const productId in delivery.jarsDelivered) {
            const currentCount = newJarsHeld[productId] || 0;
            const deliveryCount = delivery.jarsDelivered[productId] || 0;
            newJarsHeld[productId] = Math.max(0, currentCount - deliveryCount);
          }
        }
        
        await supabase
          .from('customers')
          .update({ 
            jars_held: newJarsHeld,
            updated_at: new Date().toISOString() 
          })
          .eq('id', delivery.customerId);
      }
      
      return Promise.resolve();
    } catch (error: any) {
      console.error('Error removing delivery:', error.message);
      toast({
        title: "Error removing delivery",
        description: error.message,
        variant: "destructive"
      });
      return Promise.reject(error);
    }
  };

  return {
    deliveries,
    addDelivery,
    updateDelivery,
    removeDelivery,
    loading,
  };
}
