
import { useState, useEffect } from "react";
import { Customer } from "@/types";
import { supabase } from "@/lib/supabase";
import { useToast } from "@/hooks/use-toast";

export function useCustomers() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  // Fetch customers from Supabase
  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        setLoading(true);
        const { data, error } = await supabase
          .from('customers')
          .select('*');

        if (error) {
          throw error;
        }

        if (data) {
          // Ensure we properly convert the jarsHeld JSON to the expected type
          const formattedCustomers: Customer[] = data.map((customer) => ({
            id: customer.id,
            name: customer.name,
            // Explicitly cast the jarsHeld to the expected type
            jarsHeld: customer.jars_held as { [productId: string]: number },
            address: customer.address || undefined,
            contactNumber: customer.contact_number || undefined,
            groupId: customer.in_group || undefined, // Fixed: using in_group instead of group_id
            paymentBalance: customer.payment_balance || undefined,
          }));

          setCustomers(formattedCustomers);
        }
      } catch (error: any) {
        console.error('Error fetching customers:', error.message);
        toast({
          title: "Error fetching customers",
          description: error.message,
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    fetchCustomers();

    // Subscribe to changes in the customers table
    const subscription = supabase
      .channel('public:customers')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'customers' }, async () => {
        await fetchCustomers();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(subscription);
    };
  }, [toast]);

  // Customer management functions
  const addCustomer = async (customer: Omit<Customer, "id">) => {
    try {
      const { data, error } = await supabase
        .from('customers')
        .insert([{
          name: customer.name,
          jars_held: customer.jarsHeld,
          address: customer.address || null,
          contact_number: customer.contactNumber || null,
          in_group: customer.groupId || null, // Fixed: using in_group instead of group_id
          payment_balance: customer.paymentBalance || null,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }])
        .select()
        .single();

      if (error) throw error;

      if (data) {
        const newCustomer: Customer = {
          id: data.id,
          name: data.name,
          // Explicitly cast the jarsHeld to the expected type
          jarsHeld: data.jars_held as { [productId: string]: number },
          address: data.address || undefined,
          contactNumber: data.contact_number || undefined,
          groupId: data.in_group || undefined, // Fixed: using in_group instead of group_id
          paymentBalance: data.payment_balance || undefined,
        };

        setCustomers((prev) => [...prev, newCustomer]);
      }
    } catch (error: any) {
      console.error('Error adding customer:', error.message);
      toast({
        title: "Error adding customer",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const updateCustomer = async (id: string, customer: Partial<Customer>) => {
    try {
      // Convert from client model to database model
      const dbCustomer: any = {};
      if (customer.name !== undefined) dbCustomer.name = customer.name;
      if (customer.jarsHeld !== undefined) dbCustomer.jars_held = customer.jarsHeld;
      if (customer.address !== undefined) dbCustomer.address = customer.address;
      if (customer.contactNumber !== undefined) dbCustomer.contact_number = customer.contactNumber;
      if (customer.groupId !== undefined) dbCustomer.in_group = customer.groupId; // Fixed: using in_group instead of group_id
      if (customer.paymentBalance !== undefined) dbCustomer.payment_balance = customer.paymentBalance;
      dbCustomer.updated_at = new Date().toISOString();

      const { error } = await supabase
        .from('customers')
        .update(dbCustomer)
        .eq('id', id);

      if (error) throw error;

      // Update the local state immediately to reflect changes
      setCustomers((prev) =>
        prev.map((c) => (c.id === id ? { ...c, ...customer } : c))
      );
    } catch (error: any) {
      console.error('Error updating customer:', error.message);
      toast({
        title: "Error updating customer",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const removeCustomer = async (id: string) => {
    try {
      const { error } = await supabase
        .from('customers')
        .delete()
        .eq('id', id);

      if (error) throw error;

      setCustomers((prev) => prev.filter((c) => c.id !== id));
    } catch (error: any) {
      console.error('Error removing customer:', error.message);
      toast({
        title: "Error removing customer",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  // Customer group assignment functions
  const assignCustomerToGroup = async (customerId: string, groupId: string) => {
    await updateCustomer(customerId, { groupId });
  };

  const removeCustomerFromGroup = async (customerId: string) => {
    await updateCustomer(customerId, { groupId: undefined });
  };

  const addDailyEntry = async (customerId: string, data: {
    delivery?: { [productId: string]: number };
    collection?: { [productId: string]: number; amount?: number };
    payment?: { amount: number; paymentMethod: "cash" | "card" | "bank_transfer" };
    date?: string;
  }) => {
    try {
      const timestamp = new Date().toISOString();
      const entryDate = data.date || timestamp;
      
      // Start by getting the customer
      const { data: customerData, error: customerError } = await supabase
        .from("customers")
        .select("jars_held, payment_balance")
        .eq("id", customerId)
        .single();
        
      if (customerError) throw customerError;
      
      // Calculate jar updates
      const currentJarsHeld = customerData?.jars_held as Record<string, number> || {};
      const updatedJarsHeld = { ...currentJarsHeld };
      let invoiceAmount = 0;
      let collectedAmount = 0;
      
      // Handle deliveries (jars in)
      if (data.delivery && Object.keys(data.delivery).length > 0) {
        const jarsIn = data.delivery;
        
        // Update jar counts
        Object.entries(jarsIn).forEach(([key, value]) => {
          updatedJarsHeld[key] = (updatedJarsHeld[key] || 0) + value;
        });
        
        // Create delivery record
        await supabase.from("deliveries").insert({
          customer_id: customerId,
          date: entryDate,
          jars_in: jarsIn,
          created_at: timestamp,
          updated_at: timestamp
        });
      }
      
      // Handle collections (jars returned)
      if (data.collection && Object.keys(data.collection).length > 0) {
        const jarsReturned: Record<string, number> = {};
        Object.entries(data.collection).forEach(([key, value]) => {
          if (key !== 'amount' && value > 0) {
            jarsReturned[key] = value;
            // Subtract returned jars
            updatedJarsHeld[key] = Math.max(0, (updatedJarsHeld[key] || 0) - value);
          }
        });
        
        if (Object.keys(jarsReturned).length > 0) {
          // Save the collected amount if present
          const collectionAmount = data.collection.amount || 0;
          
          await supabase.from("collections").insert({
            customer_id: customerId,
            date: entryDate,
            jars_returned: jarsReturned,
            amount: collectionAmount,
            created_at: timestamp,
            updated_at: timestamp
          });
          
          if (data.collection.amount) {
            collectedAmount = data.collection.amount;
          }
        }
      }
      
      // Handle payment
      if (data.payment) {
        collectedAmount += data.payment.amount;
        
        await supabase.from("payments").insert({
          customer_id: customerId,
          date: entryDate,
          amount: data.payment.amount,
          payment_method: data.payment.paymentMethod,
          created_at: timestamp,
          updated_at: timestamp,
          status: 'completed'
        });
      }
      
      // Update customer's jar count and payment balance
      const currentBalance = customerData?.payment_balance || 0;
      const newBalance = currentBalance - collectedAmount + invoiceAmount;
      
      await supabase
        .from('customers')
        .update({ 
          jars_held: updatedJarsHeld,
          payment_balance: newBalance,
          updated_at: timestamp
        })
        .eq('id', customerId);
        
      // Update local state
      setCustomers(prev => 
        prev.map(customer => {
          if (customer.id === customerId) {
            return {
              ...customer, 
              jarsHeld: updatedJarsHeld,
              paymentBalance: newBalance
            };
          }
          return customer;
        })
      );
      
      // Also store a consolidated entry in the deliveries table for easier history tracking
      // This enables us to properly show all info in one entry in the history view
      await supabase.from("deliveries").insert({
        customer_id: customerId,
        date: entryDate,
        jars_in: data.delivery || {},
        // Store collection data in the amount field as JSON for retrieval in history
        collection: data.collection || {},
        // Store payment data directly
        payment: data.payment?.amount || 0,
        created_at: timestamp,
        updated_at: timestamp
      });
      
      return Promise.resolve();
    } catch (error: any) {
      console.error('Error adding daily entry:', error.message);
      toast({
        title: "Error adding daily entry",
        description: error.message,
        variant: "destructive"
      });
      return Promise.reject(error);
    }
  };

  return {
    customers,
    setCustomers,
    addCustomer,
    updateCustomer,
    removeCustomer,
    assignCustomerToGroup,
    removeCustomerFromGroup,
    addDailyEntry,
    loading,
  };
}
