
import { useState, useEffect } from "react";
import { Payment } from "@/types";
import { supabase } from "@/lib/supabase";
import { useToast } from "@/hooks/use-toast";

export function usePayments() {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  // Fetch payments from Supabase
  useEffect(() => {
    const fetchPayments = async () => {
      try {
        setLoading(true);
        const { data, error } = await supabase
          .from('payments')
          .select('*');

        if (error) {
          throw error;
        }

        if (data) {
          const formattedPayments: Payment[] = data.map((payment) => ({
            id: payment.id,
            customerId: payment.customer_id,
            date: payment.date,
            amount: payment.amount,
            paymentMethod: payment.payment_method as 'cash' | 'card' | 'bank_transfer',
            status: payment.status as 'pending' | 'completed' | 'failed',
          }));

          setPayments(formattedPayments);
        }
      } catch (error: any) {
        console.error('Error fetching payments:', error.message);
        toast({
          title: "Error fetching payments",
          description: error.message,
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    fetchPayments();

    // Subscribe to changes in the payments table
    const subscription = supabase
      .channel('public:payments')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'payments' }, async () => {
        await fetchPayments();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(subscription);
    };
  }, [toast]);

  // Payment management functions
  const addPayment = async (payment: Omit<Payment, "id">) => {
    try {
      // Update Supabase
      const { data, error } = await supabase
        .from('payments')
        .insert([{
          customer_id: payment.customerId,
          date: payment.date,
          amount: payment.amount,
          payment_method: payment.paymentMethod,
          status: payment.status,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }])
        .select()
        .single();

      if (error) throw error;

      if (data) {
        const newPayment: Payment = {
          id: data.id,
          customerId: data.customer_id,
          date: data.date,
          amount: data.amount,
          paymentMethod: data.payment_method as 'cash' | 'card' | 'bank_transfer',
          status: data.status as 'pending' | 'completed' | 'failed',
        };

        setPayments((prev) => [...prev, newPayment]);
        
        // Update customer balance if needed
        if (payment.status === 'completed') {
          const { data: customerData, error: customerError } = await supabase
            .from('customers')
            .select('payment_balance')
            .eq('id', payment.customerId)
            .single();
            
          if (!customerError && customerData) {
            const currentBalance = customerData.payment_balance || 0;
            const newBalance = currentBalance - payment.amount;
            
            await supabase
              .from('customers')
              .update({ 
                payment_balance: newBalance,
                updated_at: new Date().toISOString()
              })
              .eq('id', payment.customerId);
          }
        }
      }
      return Promise.resolve();
    } catch (error: any) {
      console.error('Error adding payment:', error.message);
      toast({
        title: "Error adding payment",
        description: error.message,
        variant: "destructive",
      });
      return Promise.reject(error);
    }
  };

  const updatePayment = async (id: string, payment: Partial<Payment>) => {
    try {
      const oldPayment = payments.find(p => p.id === id);
      if (!oldPayment) throw new Error("Payment not found");
      
      // Convert from client model to database model
      const dbPayment: any = {};
      if (payment.customerId !== undefined) dbPayment.customer_id = payment.customerId;
      if (payment.date !== undefined) dbPayment.date = payment.date;
      if (payment.amount !== undefined) dbPayment.amount = payment.amount;
      if (payment.paymentMethod !== undefined) dbPayment.payment_method = payment.paymentMethod;
      if (payment.status !== undefined) dbPayment.status = payment.status;
      dbPayment.updated_at = new Date().toISOString();

      const { error } = await supabase
        .from('payments')
        .update(dbPayment)
        .eq('id', id);

      if (error) throw error;

      // Update local state
      setPayments((prev) =>
        prev.map((p) => (p.id === id ? { ...p, ...payment } : p))
      );
      
      // Handle customer balance updates based on status changes
      if (oldPayment && payment.status) {
        const { data: customerData, error: customerError } = await supabase
          .from('customers')
          .select('payment_balance')
          .eq('id', oldPayment.customerId)
          .single();
          
        if (!customerError && customerData) {
          let balanceAdjustment = 0;
          const currentBalance = customerData.payment_balance || 0;
          
          // If previously completed but now not completed, add payment amount back to balance
          if (oldPayment.status === 'completed' && payment.status !== 'completed') {
            balanceAdjustment = oldPayment.amount;
          }
          // If previously not completed but now completed, subtract payment amount from balance
          else if (oldPayment.status !== 'completed' && payment.status === 'completed') {
            balanceAdjustment = -oldPayment.amount;
          }
          
          if (balanceAdjustment !== 0) {
            const newBalance = currentBalance + balanceAdjustment;
            
            await supabase
              .from('customers')
              .update({ 
                payment_balance: newBalance,
                updated_at: new Date().toISOString()
              })
              .eq('id', oldPayment.customerId);
          }
        }
      }
      return Promise.resolve();
    } catch (error: any) {
      console.error('Error updating payment:', error.message);
      toast({
        title: "Error updating payment",
        description: error.message,
        variant: "destructive",
      });
      return Promise.reject(error);
    }
  };

  const removePayment = async (id: string) => {
    try {
      const payment = payments.find(p => p.id === id);
      if (!payment) throw new Error("Payment not found");
      
      const { error } = await supabase
        .from('payments')
        .delete()
        .eq('id', id);

      if (error) throw error;

      // Update local state
      setPayments((prev) => prev.filter((p) => p.id !== id));
      
      // Restore customer balance if payment was completed
      if (payment.status === 'completed') {
        const { data: customerData, error: customerError } = await supabase
          .from('customers')
          .select('payment_balance')
          .eq('id', payment.customerId)
          .single();
          
        if (!customerError && customerData) {
          const currentBalance = customerData.payment_balance || 0;
          const newBalance = currentBalance + payment.amount;
          
          await supabase
            .from('customers')
            .update({ 
              payment_balance: newBalance,
              updated_at: new Date().toISOString()
            })
            .eq('id', payment.customerId);
        }
      }
      return Promise.resolve();
    } catch (error: any) {
      console.error('Error removing payment:', error.message);
      toast({
        title: "Error removing payment",
        description: error.message,
        variant: "destructive",
      });
      return Promise.reject(error);
    }
  };

  return {
    payments,
    addPayment,
    updatePayment,
    removePayment,
    loading
  };
}
