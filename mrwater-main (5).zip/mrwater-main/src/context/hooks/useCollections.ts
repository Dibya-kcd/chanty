
import { useState, useEffect } from "react";
import { Collection } from "@/types";
import { supabase } from "@/lib/supabase";
import { useToast } from "@/hooks/use-toast";

export function useCollections() {
  const [collections, setCollections] = useState<Collection[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const { toast } = useToast();

  // Fetch collections from Supabase
  useEffect(() => {
    const fetchCollections = async () => {
      try {
        setLoading(true);
        const { data, error } = await supabase
          .from('collections')
          .select('*');

        if (error) {
          throw error;
        }

        if (data) {
          const formattedCollections: Collection[] = data.map((collection) => ({
            id: collection.id,
            customerId: collection.customer_id,
            date: collection.date,
            amount: collection.amount,
            jarsReturned: collection.jars_returned as { [productId: string]: number },
            status: 'completed', // Default status
          }));

          setCollections(formattedCollections);
        }
      } catch (error: any) {
        console.error('Error fetching collections:', error.message);
        toast({
          title: "Error fetching collections",
          description: error.message,
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    fetchCollections();

    // Subscribe to changes in the collections table
    const subscription = supabase
      .channel('public:collections')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'collections' }, async () => {
        await fetchCollections();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(subscription);
    };
  }, [toast]);

  // Collection management functions
  const addCollection = async (collection: Omit<Collection, "id">) => {
    try {
      // Update Supabase
      const { data, error } = await supabase
        .from('collections')
        .insert([{
          customer_id: collection.customerId,
          date: collection.date,
          amount: collection.amount,
          jars_returned: collection.jarsReturned || {},
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }])
        .select()
        .single();

      if (error) throw error;

      if (data) {
        const newCollection: Collection = {
          id: data.id,
          customerId: data.customer_id,
          date: data.date,
          amount: data.amount,
          jarsReturned: data.jars_returned as { [productId: string]: number },
          status: 'completed', // Default status
        };

        setCollections((prev) => [...prev, newCollection]);
      }
      
      // Update customer jar counts if needed
      const customer = await supabase.from("customers").select("*").eq("id", collection.customerId).single();
      
      if (customer.data && customer.data.jars_held) {
        const jarsHeld = customer.data.jars_held || {};
        // Use type assertion for jarsHeld to avoid spread type error
        const newJarsHeld = { ...(jarsHeld as object) } as Record<string, number>;
        
        if (collection.jarsReturned) {
          for (const productId in collection.jarsReturned) {
            const currentCount = newJarsHeld[productId] || 0;
            const returnCount = collection.jarsReturned[productId] || 0;
            newJarsHeld[productId] = Math.max(0, currentCount - returnCount); // Ensure not negative
          }
        }
        
        await supabase
          .from('customers')
          .update({ 
            jars_held: newJarsHeld,
            updated_at: new Date().toISOString() 
          })
          .eq('id', collection.customerId);
      }
      
      return Promise.resolve();
    } catch (error: any) {
      console.error('Error adding collection:', error.message);
      toast({
        title: "Error adding collection",
        description: error.message,
        variant: "destructive",
      });
      return Promise.reject(error);
    }
  };

  const updateCollection = async (id: string, collection: Partial<Collection>) => {
    try {
      const oldCollection = collections.find(c => c.id === id);
      if (!oldCollection) throw new Error("Collection not found");
      
      // Convert from client model to database model
      const dbCollection: any = {};
      if (collection.customerId !== undefined) dbCollection.customer_id = collection.customerId;
      if (collection.date !== undefined) dbCollection.date = collection.date;
      if (collection.amount !== undefined) dbCollection.amount = collection.amount;
      if (collection.jarsReturned !== undefined) dbCollection.jars_returned = collection.jarsReturned;
      dbCollection.updated_at = new Date().toISOString();

      const { error } = await supabase
        .from('collections')
        .update(dbCollection)
        .eq('id', id);

      if (error) throw error;

      // Update local state
      setCollections((prev) => 
        prev.map((c) => c.id === id ? { ...c, ...collection } : c)
      );
      
      // Update customer jar counts if needed
      if (collection.jarsReturned) {
        const customer = await supabase.from("customers").select("*").eq("id", oldCollection.customerId).single();
        
        if (customer.data && customer.data.jars_held) {
          const jarsHeld = customer.data.jars_held || {};
          // Use type assertion for jarsHeld to avoid spread type error
          const newJarsHeld = { ...(jarsHeld as object) } as Record<string, number>;
          
          // Add back old collection quantities
          if (oldCollection.jarsReturned) {
            for (const productId in oldCollection.jarsReturned) {
              const currentCount = newJarsHeld[productId] || 0;
              const oldReturnCount = oldCollection.jarsReturned[productId] || 0;
              newJarsHeld[productId] = currentCount + oldReturnCount;
            }
          }
          
          // Remove new collection quantities
          if (collection.jarsReturned) {
            for (const productId in collection.jarsReturned) {
              const currentCount = newJarsHeld[productId] || 0;
              const newReturnCount = collection.jarsReturned[productId] || 0;
              newJarsHeld[productId] = Math.max(0, currentCount - newReturnCount);
            }
          }
          
          await supabase
            .from('customers')
            .update({ 
              jars_held: newJarsHeld,
              updated_at: new Date().toISOString() 
            })
            .eq('id', oldCollection.customerId);
        }
      }
      
      return Promise.resolve();
    } catch (error: any) {
      console.error('Error updating collection:', error.message);
      toast({
        title: "Error updating collection",
        description: error.message,
        variant: "destructive",
      });
      return Promise.reject(error);
    }
  };

  const removeCollection = async (id: string) => {
    try {
      const collection = collections.find(c => c.id === id);
      if (!collection) throw new Error("Collection not found");
      
      const { error } = await supabase
        .from('collections')
        .delete()
        .eq('id', id);

      if (error) throw error;

      // Update local state
      setCollections((prev) => prev.filter((c) => c.id !== id));
      
      // Update customer jar counts
      const customer = await supabase.from("customers").select("*").eq("id", collection.customerId).single();
      
      if (customer.data && customer.data.jars_held) {
        const jarsHeld = customer.data.jars_held || {};
        // Use type assertion for jarsHeld to avoid spread type error
        const newJarsHeld = { ...(jarsHeld as object) } as Record<string, number>;
        
        if (collection.jarsReturned) {
          for (const productId in collection.jarsReturned) {
            const currentCount = newJarsHeld[productId] || 0;
            const returnCount = collection.jarsReturned[productId] || 0;
            newJarsHeld[productId] = currentCount + returnCount;
          }
        }
        
        await supabase
          .from('customers')
          .update({ 
            jars_held: newJarsHeld,
            updated_at: new Date().toISOString() 
          })
          .eq('id', collection.customerId);
      }
      
      return Promise.resolve();
    } catch (error: any) {
      console.error('Error removing collection:', error.message);
      toast({
        title: "Error removing collection",
        description: error.message,
        variant: "destructive",
      });
      return Promise.reject(error);
    }
  };

  return {
    collections,
    addCollection,
    updateCollection,
    removeCollection,
    loading
  };
}
