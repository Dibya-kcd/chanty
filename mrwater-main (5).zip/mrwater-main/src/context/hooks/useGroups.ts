
import { useState, useEffect } from "react";
import { Group } from "@/types";
import { supabase } from "@/lib/supabase";
import { useToast } from "@/hooks/use-toast";

export function useGroups() {
  const [groups, setGroups] = useState<Group[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const { toast } = useToast();

  useEffect(() => {
    const fetchGroups = async () => {
      try {
        setLoading(true);
        const { data, error } = await supabase.from('groups').select('*');

        if (error) {
          throw error;
        }

        if (data) {
          const formattedGroups: Group[] = data.map((group) => ({
            id: group.id,
            name: group.name,
            description: group.description,
            collectionDay: group.collection_day,
            amountDue: group.amount_due,
          }));
          setGroups(formattedGroups);
        }
      } catch (error: any) {
        console.error('Error fetching groups:', error.message);
        toast({
          title: "Error fetching groups",
          description: error.message,
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    fetchGroups();
    const subscription = supabase
      .channel('public:groups')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'groups' }, async () => {
        await fetchGroups();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(subscription);
    };
  }, [toast]);

  // Group management functions
  const addGroup = async (group: Omit<Group, "id">) => {
    try {
      const { data, error } = await supabase.from('groups').insert([{ ...group }]).select().single();
      if (error) throw error;
      if (data) {
        const newGroup: Group = {
          id: data.id,
          name: data.name,
          description: data.description,
          collectionDay: data.collection_day,
          amountDue: data.amount_due,
        };
        setGroups((prev) => [...prev, newGroup]);
      }
    } catch (error: any) {
      console.error('Error adding group:', error.message);
      toast({
        title: "Error adding group",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const updateGroup = async (id: string, group: Partial<Group>) => {
    try {
      const { error } = await supabase.from('groups').update({ ...group }).eq('id', id);
      if (error) throw error;
      setGroups((prev) => prev.map((g) => (g.id === id ? { ...g, ...group } : g)));
    } catch (error: any) {
      console.error('Error updating group:', error.message);
      toast({ title: "Error updating group", description: error.message, variant: "destructive" });
    }
  };

  const removeGroup = async (id: string) => {
    try {
      const { error } = await supabase.from('groups').delete().eq('id', id);
      if (error) throw error;
      setGroups((prev) => prev.filter((g) => g.id !== id));
      // We'll handle customer group reassignment at the customer level
    } catch (error: any) {
      console.error('Error removing group:', error.message);
      toast({ title: "Error removing group", description: error.message, variant: "destructive" });
    }
  };

  return {
    groups,
    addGroup,
    updateGroup,
    removeGroup,
    loading
  };
}
