
import { useState, useEffect } from "react";
import { Product } from "@/types";
import { supabase } from "@/lib/supabase";

export const useProducts = () => {
  const [products, setProducts] = useState<Product[]>([]);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const { data, error } = await supabase
          .from("products")
          .select("*");

        if (error) {
          throw error;
        }
        if (data) {
          setProducts(data.map(p => ({
            id: p.id.toString(),
            name: p.name,
            type: p.type,
            price: p.price,
            description: p.description || "",
            inStock: p.in_stock
          })));
        }
      } catch (error) {
        console.error("Error fetching products:", error);
      }
    };
    
    fetchProducts();
    
    const productsSubscription = supabase
      .channel('products')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'products' }, payload => {
        fetchProducts();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(productsSubscription);
    };
  }, []);

  const addProduct = async (product: Omit<Product, "id">) => {
    try {
      const { data, error } = await supabase
        .from('products')
        .insert([{
          name: product.name,
          type: product.type,
          price: product.price,
          description: product.description,
          in_stock: product.inStock
        }])
        .select();
        
      if (error) throw error;
      
      if (data && data.length > 0) {
        const newProduct: Product = {
          id: data[0].id,
          name: data[0].name,
          type: data[0].type,
          price: data[0].price,
          description: data[0].description || "",
          inStock: data[0].in_stock
        };
        
        setProducts(prev => [...prev, newProduct]);
      }
    } catch (error) {
      console.error("Error adding product:", error);
    }
  };

  const updateProduct = async (id: string, product: Partial<Product>) => {
    try {
      const dbProduct: any = {};
      if (product.name !== undefined) dbProduct.name = product.name;
      if (product.type !== undefined) dbProduct.type = product.type;
      if (product.price !== undefined) dbProduct.price = product.price;
      if (product.description !== undefined) dbProduct.description = product.description;
      if (product.inStock !== undefined) dbProduct.in_stock = product.inStock;

      const { error } = await supabase
        .from('products')
        .update(dbProduct)
        .eq('id', id);
        
      if (error) throw error;
      
      // Update the local state immediately to reflect changes
      setProducts(prev =>
        prev.map(p => (p.id === id ? { ...p, ...product } : p))
      );
    } catch (error) {
      console.error("Error updating product:", error);
    }
  };

  const removeProduct = async (id: string) => {
    try {
      const { error } = await supabase
        .from("products")
        .delete()
        .eq("id", id);
        
      if (error) throw error;
      
      setProducts(prev => prev.filter(p => p.id !== id));
    } catch (error) {
      console.error("Error removing product:", error);
    }
  };

  return {
    products,
    setProducts,
    addProduct,
    updateProduct,
    removeProduct,
  };
};
