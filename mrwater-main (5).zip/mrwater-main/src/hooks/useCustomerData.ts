
import { useState, useEffect, useContext } from 'react';
import { AppContext } from '@/context/AppContext';
import { format } from 'date-fns';
import { supabase } from '@/lib/supabase';
import { Delivery, Collection, Payment } from '@/types';

export const useCustomerData = (customerId: string) => {
  const {
    customers,
    deliveries,
    collections,
    payments,
    updateCustomer,
    removeCustomer,
  } = useContext(AppContext);

  const [name, setName] = useState('');
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [address, setAddress] = useState('');
  const [contactNumber, setContactNumber] = useState('');
  const [groupId, setGroupId] = useState<string | undefined>(undefined);
  const [productJars, setProductJars] = useState<Record<string, number>>({});
  const [paymentBalance, setPaymentBalance] = useState<number>(0);
  const [depositDate, setDepositDate] = useState<string>(format(new Date(), 'yyyy-MM-dd'));
  const [category, setCategory] = useState<string>('residential');
  const [discountRate, setDiscountRate] = useState<number>(0);
  const [isActive, setIsActive] = useState<boolean>(true);
  const [notes, setNotes] = useState<string>('');
  const [securityDeposit, setSecurityDeposit] = useState<number>(0);
  const [initialCoolBalance, setInitialCoolBalance] = useState<number>(0);
  const [initialPetBalance, setInitialPetBalance] = useState<number>(0);

  const customer = customers.find((c) => c.id === customerId);
  const customerDeliveries: Delivery[] = deliveries.filter((d) => d.customerId === customerId);
  const customerCollections: Collection[] = collections.filter((c) => c.customerId === customerId);
  const customerPayments: Payment[] = payments.filter((p) => p.customerId === customerId);

  useEffect(() => {
    setIsLoading(true);
    if (customer) {
      setName(customer.name);
      setAddress(customer.address || '');
      setContactNumber(customer.contactNumber || '');
      setGroupId(customer.groupId);
      setProductJars(customer.jarsHeld || {});
      setPaymentBalance(customer.paymentBalance || 0);
      setDepositDate(customer.depositDate || format(new Date(), 'yyyy-MM-dd'));
      setCategory(customer.category || 'residential');
      setDiscountRate(customer.discountRate || 0);
      setIsActive(customer.isActive ?? true);
      setNotes(customer.notes || '');
      setSecurityDeposit(customer.securityDeposit || 0);
      setInitialCoolBalance(customer.initialCoolBalance || 0);
      setInitialPetBalance(customer.initialPetBalance || 0);
      setIsLoading(false);
    } else {
      setIsLoading(false);
    }
  }, [customer]);
  
  useEffect(() => {
    if (!customerId) return;

    const subscription = supabase
      .channel('deliveries')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'deliveries',
          filter: `customer_id=eq.${customerId}`,
        },
        (payload) => {
          // Handle real-time changes in the 'deliveries' table
          console.log('Change received!', payload);
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [customerId]);
  
  const logTransactionChange = async (entityType: 'delivery' | 'collection' | 'payment' | 'dailyEntry', entityId: string, action: 'created' | 'updated' | 'deleted', changes: any) => {
    const actualEntityType = entityType === 'dailyEntry' ? 'delivery' : entityType;

    try {
      await supabase.from('transaction').insert([{
        customer_id: customerId,
        entity_type: actualEntityType,
        entity_id: entityId,
        action,
        changes
      }]);

    } catch (error) {
      console.error('Error logging transaction:', error);
    }
  };

  const logDeliveryChange = async (customerId: string, delivery: number, collection: number, payment: number) => {
    try {
      await supabase.from('deliveries').insert([{
        customer_id: customerId,
        date: format(new Date(), 'yyyy-MM-dd'),
        jars_in: {
          pet: delivery > 0 ? delivery : 0,
          cool: 0
        },
        amount: payment || 0,
      }]);

      if (collection > 0) {
        await supabase.from('collections').insert([{
          customer_id: customerId,
          date: format(new Date(), 'yyyy-MM-dd'),
          amount: 0,
          jars_returned: {
            pet: collection,
            cool: 0
          }
        }]);
      }

    } catch (error) {
      console.error('Error logging delivery change:', error);
    }
  };
  
  return {
    isLoading,
    customer,
    customerDeliveries,
    customerCollections,
    customerPayments,
    name, setName, 
    address, setAddress, 
    contactNumber, setContactNumber,
    groupId, setGroupId,
    productJars, setProductJars,
    paymentBalance, setPaymentBalance,
    depositDate, setDepositDate,
    category, setCategory, 
    discountRate, setDiscountRate, 
    isActive, setIsActive, 
    notes, setNotes,
    securityDeposit, setSecurityDeposit,
    initialCoolBalance, setInitialCoolBalance,
    initialPetBalance, setInitialPetBalance,
    updateCustomer,
    removeCustomer,
    logTransactionChange,
    logDeliveryChange
  };
};
