import { createClient } from "@supabase/supabase-js";

const supabaseUrl = "https://vpjljgoxokfdqaxlqvyv.supabase.co";
const supabaseAnonKey =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZwamxqZ294b2tmZHtheGxxdnl2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE2ODk0NDY5MzMsImV4cCI6MjAwNTAyMjkzM30.B5v0jXgT7S2v7v4wG4H5F5G_hXj62oYgJgL1G5s9170";

export const supabase = createClient(supabaseUrl, supabaseAnonKey);